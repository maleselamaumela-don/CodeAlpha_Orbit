from datetime import timedelta
from io import BytesIO
import json
from pathlib import Path
import tempfile
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.db import IntegrityError
from django.core.management import call_command
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone
from PIL import Image

from . import views
from .forms import PostForm
from .management.commands.seed_demo_posts import DEMO_POSTS, IMAGE_BY_POST, LEGACY_CAPTIONS
from .models import CallSession, CallSignal, Comment, CommentLike, DirectMessage, Follow, Like, Post

User = get_user_model()


class SocialModelTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="orbit_user", email="user@example.com", password="Strong-pass-123")
        self.other = User.objects.create_user(username="another_user", email="other@example.com", password="Strong-pass-123")

    def test_posts_comments_and_follow_relationships(self):
        post = Post.objects.create(author=self.user, text="Hello Orbit")
        comment = Comment.objects.create(post=post, author=self.other, text="Welcome!")
        follow = Follow.objects.create(follower=self.other, following=self.user)

        self.assertEqual(post.comments.get(), comment)
        self.assertEqual(self.user.follower_count, 1)
        self.assertEqual(self.other.following_count, 1)
        self.assertEqual(follow.following, self.user)

    def test_follow_relationship_is_unique(self):
        Follow.objects.create(follower=self.other, following=self.user)
        with self.assertRaises(IntegrityError):
            Follow.objects.create(follower=self.other, following=self.user)

    def test_comment_like_relationship_is_unique(self):
        post = Post.objects.create(author=self.user, text="Post with a comment")
        comment = Comment.objects.create(post=post, author=self.other, text="A comment")
        CommentLike.objects.create(comment=comment, user=self.user)

        with self.assertRaises(IntegrityError):
            CommentLike.objects.create(comment=comment, user=self.user)

    def test_user_can_like_and_unlike_a_post(self):
        post = Post.objects.create(author=self.other, text="Like this post")

        self.client.force_login(self.user)
        response = self.client.post(reverse("toggle_like", args=[post.pk]))
        self.assertRedirects(response, reverse("home"))
        self.assertTrue(Like.objects.filter(post=post, user=self.user).exists())

        response = self.client.post(reverse("toggle_like", args=[post.pk]))
        self.assertRedirects(response, reverse("home"))
        self.assertFalse(Like.objects.filter(post=post, user=self.user).exists())

    def test_like_ajax_request_returns_updated_state_without_redirect(self):
        post = Post.objects.create(author=self.other, text="Like without reloading")
        url = reverse("toggle_like", args=[post.pk])
        self.client.force_login(self.user)

        response = self.client.post(url, HTTP_ACCEPT="application/json")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"liked": True, "like_count": 1})
        self.assertFalse(response.has_header("Location"))

        response = self.client.post(url, HTTP_ACCEPT="application/json")

        self.assertEqual(response.json(), {"liked": False, "like_count": 0})
        self.assertFalse(Like.objects.filter(post=post, user=self.user).exists())

    def test_multiple_users_can_like_same_post_and_feed_shows_current_state(self):
        post = Post.objects.create(author=self.user, text="My post")
        Like.objects.create(post=post, user=self.other)

        self.client.force_login(self.user)
        response = self.client.get(reverse("home"))

        self.assertContains(response, 'aria-pressed="false"')
        self.assertEqual(response.context["posts"].get(pk=post.pk).like_count, 1)
        self.client.post(reverse("toggle_like", args=[post.pk]))
        self.assertEqual(Like.objects.filter(post=post).count(), 2)

        response = self.client.get(reverse("home"))
        self.assertContains(response, 'aria-pressed="true"')
        self.assertEqual(response.context["posts"].get(pk=post.pk).like_count, 2)


class SocialViewTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="orbit_user", email="user@example.com", password="Strong-pass-123")
        self.client.force_login(self.user)
        self.media_directory = tempfile.TemporaryDirectory()
        self.media_settings = override_settings(MEDIA_ROOT=self.media_directory.name)
        self.media_settings.enable()
        self.addCleanup(self.media_settings.disable)
        self.addCleanup(self.media_directory.cleanup)

    def image_upload(self, color, name):
        image_data = BytesIO()
        Image.new("RGB", (2, 2), color).save(image_data, format="PNG")
        return SimpleUploadedFile(name, image_data.getvalue(), content_type="image/png")

    def test_registration_creates_user_and_logs_them_in(self):
        self.client.logout()
        response = self.client.post(
            reverse("register"),
            {
                "username": "new_orbit_user",
                "email": "new@example.com",
                "password1": "Orbit-safe!92834",
                "password2": "Orbit-safe!92834",
            },
        )

        self.assertRedirects(response, reverse("home"))
        new_user = User.objects.get(username="new_orbit_user")
        self.assertEqual(self.client.session.get("_auth_user_id"), str(new_user.pk))

    def test_create_post_and_comment(self):
        self.client.post(
            reverse("home"),
            {"text": "A post from Django"},
        )
        post = Post.objects.get(author=self.user)
        response = self.client.post(reverse("add_comment", args=[post.pk]), {"text": "A database-backed comment"})

        self.assertRedirects(response, reverse("home"))
        self.assertEqual(Comment.objects.get(post=post).text, "A database-backed comment")

    def test_post_form_and_feed_no_longer_show_categories(self):
        response = self.client.get(reverse("home"))

        self.assertNotIn("category", PostForm().fields)
        self.assertContains(response, "Write a caption that describes your photo")
        self.assertNotContains(response, "Category")

    def test_users_can_comment_on_other_users_posts(self):
        other = User.objects.create_user(
            username="comment_post_author",
            email="comment-post-author@example.com",
            password="Local-test-password-123!",
        )
        post = Post.objects.create(author=other, text="A post from another user")

        response = self.client.post(
            reverse("add_comment", args=[post.pk]),
            {"text": "A comment from another account"},
        )

        self.assertRedirects(response, reverse("home"))
        self.assertTrue(
            Comment.objects.filter(
                post=post,
                author=self.user,
                text="A comment from another account",
            ).exists()
        )

    def test_comment_can_be_liked_and_unliked_without_refresh(self):
        post = Post.objects.create(author=self.user, text="Comment interaction test")
        commenter = User.objects.create_user(
            username="comment_like_author",
            email="comment-like-author@example.com",
            password="Local-test-password-123!",
        )
        comment = Comment.objects.create(post=post, author=commenter, text="Like this comment")
        url = reverse("toggle_comment_like", args=[comment.pk])

        response = self.client.post(url, HTTP_ACCEPT="application/json")

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), {"liked": True, "like_count": 1})
        self.assertFalse(response.has_header("Location"))

        response = self.client.post(url, HTTP_ACCEPT="application/json")

        self.assertEqual(response.json(), {"liked": False, "like_count": 0})
        self.assertFalse(CommentLike.objects.filter(comment=comment, user=self.user).exists())

    def test_comment_like_state_and_count_are_rendered(self):
        post = Post.objects.create(author=self.user, text="Comment state test")
        commenter = User.objects.create_user(
            username="liked_comment_author",
            email="liked-comment-author@example.com",
            password="Local-test-password-123!",
        )
        comment = Comment.objects.create(post=post, author=commenter, text="A liked comment")
        CommentLike.objects.create(comment=comment, user=self.user)

        response = self.client.get(reverse("home"))

        self.assertContains(response, 'aria-pressed="true"')
        self.assertContains(response, "A liked comment")
        self.assertEqual(response.context["posts"].get(pk=post.pk).comments.get().like_count, 1)

    def test_home_feed_shuffles_posts_without_excluding_them(self):
        authors = [
            User.objects.create_user(
                username=f"feed_author_{index}",
                email=f"feed-author-{index}@example.com",
                password="Local-test-password-123!",
            )
            for index in range(4)
        ]
        posts = [
            Post.objects.create(author=author, text=f"Feed post {index}")
            for index, author in enumerate(authors)
        ]

        response = self.client.get(reverse("home"))

        self.assertEqual(response.context["posts"].query.order_by, ("?",))
        self.assertEqual(
            {post.pk for post in response.context["posts"]},
            {post.pk for post in posts} | {post.pk for post in Post.objects.filter(author=self.user)},
        )

    def test_user_can_repost_another_users_post(self):
        other = User.objects.create_user(
            username="repost_author",
            email="repost@example.com",
            password="Local-test-password-123!",
        )
        original = Post.objects.create(author=other, text="Original post to repost")

        response = self.client.post(
            reverse("repost_post", args=[original.pk]),
            {"next": reverse("home")},
        )

        self.assertRedirects(response, reverse("home"))
        repost = Post.objects.get(author=self.user, repost_of=original)
        self.assertContains(self.client.get(reverse("home")), "Reposted by @orbit_user")

        self.client.post(reverse("toggle_like", args=[repost.pk]))
        self.assertTrue(Like.objects.filter(post=original, user=self.user).exists())
        self.client.post(
            reverse("add_comment", args=[repost.pk]),
            {"text": "Comment on the original"},
        )
        self.assertTrue(Comment.objects.filter(post=original, author=self.user).exists())

        self.client.post(reverse("repost_post", args=[original.pk]))
        self.assertEqual(Post.objects.filter(author=self.user, repost_of=original).count(), 1)

    def test_repost_ajax_request_returns_updated_state_without_redirect(self):
        other = User.objects.create_user(
            username="ajax_repost_author",
            email="ajax-repost@example.com",
            password="Local-test-password-123!",
        )
        post = Post.objects.create(author=other, text="Repost without reloading")

        response = self.client.post(
            reverse("repost_post", args=[post.pk]),
            HTTP_ACCEPT="application/json",
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.json(),
            {"reposted": True, "created": True, "repost_count": 1},
        )
        self.assertFalse(response.has_header("Location"))

    def test_post_can_be_opened_and_shared_with_a_permalink(self):
        other = User.objects.create_user(
            username="share_author",
            email="share@example.com",
            password="Local-test-password-123!",
        )
        post = Post.objects.create(author=other, text="A shareable post")

        response = self.client.get(reverse("post_detail", args=[post.pk]))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "A shareable post")
        self.assertContains(
            response,
            f'data-share-url="http://testserver{reverse("post_detail", args=[post.pk])}"',
        )

    def test_user_cannot_repost_their_own_post(self):
        post = Post.objects.create(author=self.user, text="My own post")

        response = self.client.post(reverse("repost_post", args=[post.pk]))

        self.assertRedirects(response, reverse("home"))
        self.assertFalse(Post.objects.filter(author=self.user, repost_of=post).exists())

    def test_feed_displays_another_users_uploaded_photo(self):
        other = User.objects.create_user(
            username="photo_author",
            email="photo@example.com",
            password="Strong-pass-123",
        )
        image = self.image_upload("green", "shared-photo.png")
        post = Post.objects.create(author=other, text="A real uploaded photo", image=image)

        response = self.client.get(reverse("home"))

        self.assertContains(response, "A real uploaded photo")
        self.assertContains(response, post.image.url)
        self.assertContains(response, "photo_author")

    def test_explore_shows_other_users_and_their_posts(self):
        other = User.objects.create_user(
            username="explore_author",
            email="explore@example.com",
            password="Strong-pass-123",
        )
        Post.objects.create(author=other, text="Visible in Explore")

        response = self.client.get(reverse("explore"))

        self.assertContains(response, "explore_author")
        self.assertContains(response, "Visible in Explore")
        self.assertNotContains(response, self.user.username)
        self.assertContains(response, 'aria-current="page">Explore</a>')
        self.assertContains(response, 'class="explore-user-row"')
        self.assertContains(response, 'class="explore-user-actions"')

    def test_demo_seed_creates_30_posts_idempotently_and_displays_them(self):
        call_command("seed_demo_posts", verbosity=0)
        call_command("seed_demo_posts", verbosity=0)

        seeded_posts = Post.objects.exclude(author=self.user)
        self.assertEqual(seeded_posts.count(), 30)
        self.assertEqual(len(DEMO_POSTS), 30)
        self.assertEqual(len(IMAGE_BY_POST), 30)
        self.assertTrue(all(post.text in IMAGE_BY_POST for post in seeded_posts))
        self.assertEqual(seeded_posts.exclude(image="").count(), 30)
        self.assertEqual(
            set(User.objects.filter(username__in=[
                "amina_okafor", "jordan_brooks", "thabo_mokoena", "maya_carter",
                "lerato_dlamini", "marcus_reed", "zanele_khumalo", "ava_thompson",
                "kofi_mensah", "ethan_miller",
            ]).values_list("username", flat=True)),
            {
                "amina_okafor", "jordan_brooks", "thabo_mokoena", "maya_carter",
                "lerato_dlamini", "marcus_reed", "zanele_khumalo", "ava_thompson",
                "kofi_mensah", "ethan_miller",
            },
        )
        self.assertTrue(all(user.first_name and user.last_name for user in User.objects.filter(username__in=[
            "amina_okafor", "jordan_brooks", "thabo_mokoena", "maya_carter",
            "lerato_dlamini", "marcus_reed", "zanele_khumalo", "ava_thompson",
            "kofi_mensah", "ethan_miller",
        ])))
        self.assertEqual(
            User.objects.filter(username__in=[
                "amina_okafor", "jordan_brooks", "thabo_mokoena", "maya_carter",
                "lerato_dlamini", "marcus_reed", "zanele_khumalo", "ava_thompson",
                "kofi_mensah", "ethan_miller",
            ]).exclude(profile_picture="").count(),
            10,
        )
        self.assertTrue(all(post.image.storage.exists(post.image.name) for post in seeded_posts))

        response = self.client.get(reverse("home"))
        self.assertEqual(response.context["posts"].count(), 30)
        for post in seeded_posts:
            self.assertContains(response, post.image.url)
            expected_image_name = "".join(
                character.lower()
                for character in f"{post.pk}-{IMAGE_BY_POST[post.text]}"
                if character.isalnum()
            )
            stored_image_name = "".join(
                character.lower()
                for character in Path(post.image.name).name
                if character.isalnum()
            )
            self.assertTrue(
                stored_image_name.startswith(expected_image_name[:40])
            )
        for demo_user in User.objects.filter(username__in=[
            "amina_okafor", "jordan_brooks", "thabo_mokoena", "maya_carter",
            "lerato_dlamini", "marcus_reed", "zanele_khumalo", "ava_thompson",
            "kofi_mensah", "ethan_miller",
        ]).exclude(pk=self.user.pk):
            self.assertContains(response, demo_user.profile_picture.url)
            self.assertContains(response, demo_user.get_full_name())
        self.assertNotContains(response, "post-category")

    def test_demo_seed_renames_existing_sample_users_without_losing_posts(self):
        old_user = User.objects.create_user(
            username="orbit_founder",
            email="orbit_founder@demo.orbit.invalid",
            password=None,
        )
        existing_post = Post.objects.create(
            author=old_user,
            text="Keep this existing demo post",
        )
        legacy_caption, current_caption = next(iter(LEGACY_CAPTIONS.items()))
        legacy_post = Post.objects.create(author=old_user, text=legacy_caption)

        call_command("seed_demo_posts", verbosity=0)

        renamed_user = User.objects.get(username="amina_okafor")
        self.assertEqual(renamed_user.pk, old_user.pk)
        self.assertEqual(renamed_user.get_full_name(), "Amina Okafor")
        self.assertTrue(Post.objects.filter(pk=existing_post.pk, author=renamed_user).exists())
        legacy_post.refresh_from_db()
        self.assertEqual(legacy_post.text, current_caption)
        self.assertEqual(renamed_user.posts.filter(text=current_caption).count(), 1)

    def test_every_account_gets_demo_followers(self):
        call_command("seed_demo_posts", verbosity=0)

        self.assertTrue(all(user.followers.exists() for user in User.objects.all()))
        self.assertTrue(self.user.followers.filter(is_demo=True).exists())

    def test_demo_engagement_adds_three_likes_per_ten_minutes_up_to_thirty(self):
        call_command("seed_demo_posts", verbosity=0)
        started_at = timezone.now()
        post = Post.objects.create(
            author=self.user,
            text="A scheduled demo engagement post",
            demo_like_started_at=started_at,
        )

        for minutes, expected_count in ((9, 0), (10, 3), (20, 6), (100, 30), (120, 30)):
            with patch(
                "social.management.commands.process_demo_engagement.timezone.now",
                return_value=started_at + timedelta(minutes=minutes),
            ):
                call_command("process_demo_engagement", verbosity=0)
            self.assertEqual(
                Like.objects.filter(post=post, is_demo=True).count(),
                expected_count,
            )
        self.assertEqual(
            Like.objects.filter(post=post, is_demo=True).values("user_id").distinct().count(),
            30,
        )

    def test_demo_engagement_does_not_like_repost_entries(self):
        call_command("seed_demo_posts", verbosity=0)
        other = User.objects.create_user(
            username="reposter",
            email="reposter@example.com",
            password="Local-test-password-123!",
        )
        started_at = timezone.now()
        original = Post.objects.create(
            author=self.user,
            text="Original post",
            demo_like_started_at=started_at,
        )
        repost = Post.objects.create(author=other, repost_of=original)

        with patch(
            "social.management.commands.process_demo_engagement.timezone.now",
            return_value=started_at + timedelta(minutes=10),
        ):
            call_command("process_demo_engagement", verbosity=0)

        self.assertEqual(Like.objects.filter(post=original, is_demo=True).count(), 3)
        self.assertFalse(Like.objects.filter(post=repost, is_demo=True).exists())
        repost.refresh_from_db()
        self.assertIsNone(repost.demo_like_started_at)

    def test_profile_picture_upload_and_replacement(self):
        response = self.client.post(
            reverse("profile", args=[self.user.username]),
            {"bio": "Updated bio", "profile_picture": self.image_upload("blue", "avatar.png")},
        )
        self.assertRedirects(response, reverse("profile", args=[self.user.username]))
        self.user.refresh_from_db()
        self.assertEqual(self.user.bio, "Updated bio")
        first_picture = self.user.profile_picture.name

        response = self.client.post(
            reverse("profile", args=[self.user.username]),
            {"bio": "Updated bio", "profile_picture": self.image_upload("red", "avatar.png")},
        )
        self.assertRedirects(response, reverse("profile", args=[self.user.username]))
        self.user.refresh_from_db()
        self.assertNotEqual(self.user.profile_picture.name, first_picture)


class MessagingViewTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            username="messaging_user",
            email="messaging@example.com",
            password="Orbit-safe!92834",
        )
        self.other = User.objects.create_user(
            username="message_friend",
            email="message-friend@example.com",
            password="Orbit-safe!92834",
        )
        self.client.force_login(self.user)

    def test_sending_a_message_creates_an_automatic_reply(self):
        response = self.client.post(
            reverse("conversation", args=[self.other.username]),
            {"content": "Hello there"},
        )

        self.assertRedirects(response, reverse("conversation", args=[self.other.username]))
        sent_message, automatic_reply = DirectMessage.objects.order_by("pk")
        self.assertEqual(sent_message.sender, self.user)
        self.assertEqual(sent_message.recipient, self.other)
        self.assertEqual(sent_message.content, "Hello there")
        self.assertFalse(sent_message.is_automatic)
        self.assertEqual(automatic_reply.sender, self.other)
        self.assertEqual(automatic_reply.recipient, self.user)
        self.assertTrue(automatic_reply.is_automatic)
        self.assertIn(self.user.username, automatic_reply.content)
        self.assertIn("thanks", automatic_reply.content.lower())
        self.assertIn("soon", automatic_reply.content.lower())
        response = self.client.get(reverse("conversation", args=[self.other.username]))
        self.assertContains(response, "Quick reply")
        self.assertNotContains(response, "AUTOMATIC REPLY")
        self.assertNotContains(response, "Orbit adds a small automatic reply")

    def test_friendly_quick_replies_vary_but_are_transparent(self):
        self.user.first_name = "Morgan"
        self.user.save(update_fields=["first_name"])
        with patch(
            "social.views.random.choice",
            side_effect=["Hey {name}, thanks for reaching out!", "Hi {name}! Lovely to hear from you."],
        ):
            responses = {
                views.friendly_quick_reply(self.user),
                views.friendly_quick_reply(self.user),
            }

        self.assertEqual(len(responses), 2)
        self.assertTrue(all("Morgan" in reply for reply in responses))

    def test_inbox_and_chat_show_only_relevant_conversations(self):
        stranger = User.objects.create_user(
            username="message_stranger",
            email="message-stranger@example.com",
            password="Orbit-safe!92834",
        )
        another_user = User.objects.create_user(
            username="another_message_user",
            email="another-message-user@example.com",
            password="Orbit-safe!92834",
        )
        DirectMessage.objects.create(
            sender=self.user,
            recipient=self.other,
            content="Only for my friend",
        )
        DirectMessage.objects.create(
            sender=self.other,
            recipient=self.user,
            content="Thanks for your message! This is an automatic reply.",
            is_automatic=True,
        )
        DirectMessage.objects.create(
            sender=stranger,
            recipient=another_user,
            content="Message belonging to another conversation",
        )

        inbox_response = self.client.get(reverse("inbox"))
        chat_response = self.client.get(reverse("conversation", args=[self.other.username]))

        self.assertEqual(
            list(inbox_response.context["conversation_users"].values_list("username", flat=True)),
            [self.other.username],
        )
        self.assertContains(chat_response, "Only for my friend")
        self.assertNotContains(chat_response, "Message belonging to another conversation")

    def test_blank_messages_and_self_messages_are_rejected(self):
        response = self.client.post(
            reverse("conversation", args=[self.other.username]),
            {"content": "   "},
        )
        self.assertEqual(response.status_code, 200)
        self.assertFalse(DirectMessage.objects.exists())

        self.client.post(
            reverse("conversation", args=[self.user.username]),
            {"content": "Talking to myself"},
        )
        self.assertFalse(DirectMessage.objects.exists())

    def test_conversation_page_displays_voice_and_video_call_controls(self):
        response = self.client.get(reverse("conversation", args=[self.other.username]))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'data-start-call="voice"')
        self.assertContains(response, 'data-start-call="video"')
        self.assertContains(response, "js/calls.js")

    def test_voice_and_video_calls_exchange_signals_between_participants(self):
        response = self.client.post(
            reverse("start_call", args=[self.other.username]),
            data=json.dumps(
                {
                    "call_type": "video",
                    "offer": {"type": "offer", "sdp": "offer-sdp"},
                }
            ),
            content_type="application/json",
        )

        self.assertEqual(response.status_code, 201)
        call = CallSession.objects.get(pk=response.json()["call_id"])
        offer_signal = CallSignal.objects.get(call=call)
        self.assertEqual(call.caller, self.user)
        self.assertEqual(call.callee, self.other)
        self.assertEqual(call.call_type, CallSession.CallType.VIDEO)
        self.assertEqual(offer_signal.signal_type, CallSignal.SignalType.OFFER)

        self.client.force_login(self.other)
        incoming = self.client.get(reverse("poll_calls", args=[self.user.username]))
        self.assertEqual(incoming.json()["call"]["offer"], {"type": "offer", "sdp": "offer-sdp"})

        answer = self.client.post(
            reverse("send_call_signal", args=[call.pk]),
            data=json.dumps(
                {"type": "answer", "payload": {"type": "answer", "sdp": "answer-sdp"}}
            ),
            content_type="application/json",
        )
        self.assertEqual(answer.status_code, 201)
        call.refresh_from_db()
        self.assertEqual(call.status, CallSession.Status.ACTIVE)

        self.client.force_login(self.user)
        signals = self.client.get(
            reverse("poll_call_signals", args=[call.pk]),
            {"after": offer_signal.pk},
        )
        self.assertEqual(signals.json()["signals"][0]["type"], CallSignal.SignalType.ANSWER)

        ended = self.client.post(
            reverse("send_call_signal", args=[call.pk]),
            data=json.dumps({"type": "end"}),
            content_type="application/json",
        )
        self.assertEqual(ended.status_code, 201)
        call.refresh_from_db()
        self.assertEqual(call.status, CallSession.Status.ENDED)

    def test_call_signals_reject_invalid_or_nonparticipant_requests(self):
        response = self.client.post(
            reverse("start_call", args=[self.other.username]),
            data=json.dumps(
                {"call_type": "voice", "offer": {"type": "offer", "sdp": "offer-sdp"}}
            ),
            content_type="application/json",
        )
        call_id = response.json()["call_id"]
        stranger = User.objects.create_user(
            username="call_stranger",
            email="call-stranger@example.com",
            password="Orbit-safe!92834",
        )
        self.client.force_login(stranger)
        self.assertEqual(
            self.client.get(reverse("poll_call_signals", args=[call_id])).status_code,
            403,
        )

        self.client.force_login(self.user)
        invalid = self.client.post(
            reverse("start_call", args=[self.other.username]),
            data=json.dumps(
                {"call_type": "voice", "offer": {"type": "offer", "sdp": "offer-sdp"}}
            ),
            content_type="application/json",
        )
        self.assertEqual(invalid.status_code, 409)

    def test_follow_toggle_persists(self):
        other = User.objects.create_user(username="friend", email="friend@example.com", password="Strong-pass-123")
        self.client.post(reverse("toggle_follow", args=[other.username]))
        self.assertTrue(Follow.objects.filter(follower=self.user, following=other).exists())
        self.client.post(reverse("toggle_follow", args=[other.username]))
        self.assertFalse(Follow.objects.filter(follower=self.user, following=other).exists())
