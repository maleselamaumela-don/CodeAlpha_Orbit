from .models import Follow, User


def ensure_demo_followers(demo_users):
    if not demo_users:
        return 0

    created_count = 0
    for index, follower in enumerate(demo_users):
        following = demo_users[(index + 1) % len(demo_users)]
        _, created = Follow.objects.get_or_create(
            follower=follower,
            following=following,
            defaults={"is_demo": True},
        )
        created_count += created

    demo_ids = [user.pk for user in demo_users]
    for user in User.objects.exclude(pk__in=demo_ids):
        for offset in range(3):
            follower = demo_users[(user.pk + offset) % len(demo_users)]
            _, created = Follow.objects.get_or_create(
                follower=follower,
                following=user,
                defaults={"is_demo": True},
            )
            created_count += created

    return created_count
