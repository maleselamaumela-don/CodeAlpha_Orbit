from datetime import timedelta

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone

from social.demo_activity import ensure_demo_followers
from social.models import Like, Post, User


INTERVAL = timedelta(minutes=10)
LIKES_PER_INTERVAL = 3
MAX_DEMO_LIKES = 30


class Command(BaseCommand):
    help = "Add due, clearly marked demo likes to posts by non-demo users."

    @transaction.atomic
    def handle(self, *args, **options):
        demo_users = list(User.objects.filter(is_demo_account=True).order_by("pk"))
        if len(demo_users) < MAX_DEMO_LIKES:
            raise CommandError(
                "Run `python manage.py seed_demo_posts` first to create demo users."
            )
        followers_added = ensure_demo_followers(demo_users)

        now = timezone.now()
        posts_processed = 0
        likes_added = 0
        posts = Post.objects.select_related("author").filter(
            author__is_demo_account=False,
            repost_of__isnull=True,
        )
        for post in posts:
            if post.demo_like_started_at is None:
                post.demo_like_started_at = now
                post.save(update_fields=["demo_like_started_at"])
                posts_processed += 1
                continue

            intervals_due = max(0, int((now - post.demo_like_started_at) // INTERVAL))
            target_likes = min(MAX_DEMO_LIKES, intervals_due * LIKES_PER_INTERVAL)
            existing_demo_likes = Like.objects.filter(post=post, is_demo=True).count()
            likes_needed = max(0, target_likes - existing_demo_likes)
            if not likes_needed:
                continue

            liked_user_ids = set(
                Like.objects.filter(post=post).values_list("user_id", flat=True)
            )
            available_users = [
                user for user in demo_users
                if user.pk != post.author_id and user.pk not in liked_user_ids
            ]
            if len(available_users) < likes_needed:
                raise CommandError(
                    f"Not enough unused demo accounts to add {likes_needed} likes to post {post.pk}."
                )

            Like.objects.bulk_create(
                [
                    Like(post=post, user=user, is_demo=True)
                    for user in available_users[:likes_needed]
                ]
            )
            likes_added += likes_needed
            posts_processed += 1

        self.stdout.write(
            self.style.SUCCESS(
                f"Demo engagement processed {posts_processed} post(s); "
                f"added {likes_added} simulated like(s) and {followers_added} simulated follow(s)."
            )
        )
