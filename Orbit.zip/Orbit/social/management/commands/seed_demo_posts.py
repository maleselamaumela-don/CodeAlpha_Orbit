from pathlib import Path
from io import BytesIO

from django.conf import settings
from django.core.files.base import ContentFile
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from PIL import Image, ImageOps

from social.demo_activity import ensure_demo_followers
from social.models import Post, User


CREATORS = {
    "orbit_founder": ("amina_okafor", "Amina", "Okafor", "Building a neighborhood coffee business one thoughtful decision at a time."),
    "orbit_studio": ("jordan_brooks", "Jordan", "Brooks", "Independent team sharing practical business and creative lessons."),
    "orbit_motors": ("thabo_mokoena", "Thabo", "Mokoena", "Car culture, weekend drives and the details worth noticing."),
    "orbit_roadtrip": ("maya_carter", "Maya", "Carter", "Scenic routes, road-trip notes and car care."),
    "orbit_sound": ("lerato_dlamini", "Lerato", "Dlamini", "Independent music, songwriting and studio sessions."),
    "orbit_beats": ("marcus_reed", "Marcus", "Reed", "Producer notes from the home studio."),
    "orbit_style": ("zanele_khumalo", "Zanele", "Khumalo", "Personal style, thoughtful outfits and sustainable fashion."),
    "orbit_wardrobe": ("ava_thompson", "Ava", "Thompson", "Fashion ideas built around pieces you already own."),
    "orbit_markets": ("kofi_mensah", "Kofi", "Mensah", "Learning about markets with patience and a written plan."),
    "orbit_creator": ("ethan_miller", "Ethan", "Miller", "Videography, editing and the stories between the shots."),
}

SUPPORTERS = {
    "nomsa_mthembu": ("Nomsa", "Mthembu", "Community entrepreneur and lifelong learner."),
    "sipho_ncube": ("Sipho", "Ncube", "Sharing ideas on creativity, work and everyday life."),
    "ayanda_zulu": ("Ayanda", "Zulu", "Fashion, culture and finding your own voice."),
    "naledi_molefe": ("Naledi", "Molefe", "Curious about business and thoughtful design."),
    "kwame_boateng": ("Kwame", "Boateng", "Learning about markets with patience and care."),
    "ama_osei": ("Ama", "Osei", "Music fan, maker and supporter of independent artists."),
    "chidi_okoye": ("Chidi", "Okoye", "Building good habits one project at a time."),
    "tendai_moyo": ("Tendai", "Moyo", "Documenting small moments and new places."),
    "makena_otieno": ("Makena", "Otieno", "Books, education and sharing what I learn."),
    "thandiwe_sithole": ("Thandiwe", "Sithole", "Style notes and sustainable wardrobe ideas."),
    "kevin_washington": ("Kevin", "Washington", "Business-minded creative and weekend car enthusiast."),
    "olivia_jackson": ("Olivia", "Jackson", "Photographs, playlists and good stories."),
    "noah_johnson": ("Noah", "Johnson", "Learning to make videos that feel human."),
    "sophia_williams": ("Sophia", "Williams", "Curious about small business and community."),
    "elijah_bennett": ("Elijah", "Bennett", "Music production and the craft behind a good mix."),
    "imani_james": ("Imani", "James", "Sharing practical lessons from the learning process."),
    "caleb_mitchell": ("Caleb", "Mitchell", "Cars, cameras and exploring new roads."),
    "zoe_davis": ("Zoe", "Davis", "Personal style with comfort and confidence."),
    "mason_clark": ("Mason", "Clark", "A curious student of business and technology."),
    "harper_morgan": ("Harper", "Morgan", "Videographer finding stories in everyday life."),
}


DEMO_POSTS = [
    ("orbit_founder", "A business idea is only the start: choose a location, brainstorm a name, and map out the steps to get it moving."),
    ("orbit_studio", "A bright reminder to back yourself, take ownership, and build the work you want to be known for."),
    ("orbit_founder", "A milestone worth celebrating: one million orders, built one customer and one delivery at a time."),
    ("orbit_studio", "A dashboard full of numbers is most useful when it helps you decide what to do next."),
    ("orbit_founder", "A busy day surrounded by orders and stock - grateful to see the work coming together."),
    ("orbit_motors", "A quiet early-morning drive is still my favorite way to appreciate a well-balanced car."),
    ("orbit_roadtrip", "A closer look at the front end, clean lines, and bright headlights on this Mercedes."),
    ("orbit_motors", "A showroom full of choices - always fun to compare the details on each car."),
    ("orbit_roadtrip", "A lineup like this makes you want to plan the next drive and take the long way home."),
    ("orbit_motors", "Good people, sharp suits, and an evening worth remembering."),
    ("orbit_sound", "A late-night link-up in Atlanta, with the cars and city lights setting the scene."),
    ("orbit_beats", "Good company and a well-dressed crew make for a memorable evening."),
    ("orbit_sound", "Travel day essentials: patience, a full trolley, and somewhere new to go."),
    ("orbit_beats", "On the move again - there is always a new place and a new story ahead."),
    ("orbit_style", "Streetwear drop day: a bold graphic, a stack of denim, and a look that speaks for itself."),
    ("orbit_wardrobe", "Behind the scenes at the workshop, where the next run of pieces starts taking shape."),
    ("orbit_style", "A closer look at the textures, layers, and details that give a collection its character."),
    ("orbit_wardrobe", "A comfortable outfit can still feel considered. Fit and fabric do a lot of the work."),
    ("orbit_markets", "Trading journal reminder: write down the plan before the chart gets exciting. Risk limits come first."),
    ("orbit_markets", "A watchlist is not a signal. I am practicing waiting for my criteria instead of chasing a fast move."),
    ("orbit_markets", "Reviewing the week: record the reasoning behind each decision, not just whether it made money."),
    ("orbit_markets", "Learning the markets takes patience: study the ideas, review your notes, and make careful decisions."),
    ("orbit_creator", "A steady shot starts before you press record: find your frame, check the light, and take a breath."),
    ("orbit_creator", "Editing tip from today: let the scene breathe. Cutting every pause can take the feeling out of an interview."),
    ("orbit_creator", "A great moment from the match - quick reactions, sharp movement, and everyone focused on the play."),
    ("orbit_creator", "Behind the scenes: organize clips while the shoot is still fresh. Future-you will be grateful."),
    ("orbit_studio", "Learning something difficult gets easier when you break it into a small daily practice you can actually keep."),
    ("orbit_founder", "A good question is a learning tool. I keep a note of what I do not understand and look it up after class."),
    ("orbit_studio", "Study session idea: explain the concept in your own words, then check which parts still feel unclear."),
    ("orbit_creator", "A lecture hall full of ideas - always something new to take away from a shared learning space."),
]

LEGACY_CAPTIONS = {
    "A useful business plan is one you revisit. This week I replaced three guesses with real customer conversations.": DEMO_POSTS[0][1],
    "Small teams move faster when everyone knows what a good outcome looks like. Write the goal down before the meeting.": DEMO_POSTS[1][1],
    "First lesson from opening a neighborhood coffee counter: consistency earns trust long before a big launch does.": DEMO_POSTS[2][1],
    "A simple dashboard is only helpful when it answers a real question. Start with the decision, then choose the metric.": DEMO_POSTS[3][1],
    "Today\u2019s business win was a returning customer by name. It is a better reminder than any spreadsheet.": DEMO_POSTS[4][1],
    "A quiet early-morning drive is still my favorite way to appreciate a well-balanced car.": DEMO_POSTS[5][1],
    "Road-trip checklist: tire pressure, water, a charged phone, and enough time to take the scenic route.": DEMO_POSTS[6][1],
    "The best interior upgrade is the one that makes every drive more comfortable without adding clutter.": DEMO_POSTS[7][1],
    "Found a beautiful back road today. Slow down, leave room for cyclists, and enjoy the view.": DEMO_POSTS[8][1],
    "Car care note: a clean windshield and correctly set mirrors make a bigger difference than people think.": DEMO_POSTS[9][1],
    "A melody recorded on a phone can still hold the feeling of the whole song. Capture the idea first; polish it later.": DEMO_POSTS[10][1],
    "Tonight\u2019s session: one drum pattern, a warm bass line, and plenty of space for the vocal.": DEMO_POSTS[11][1],
    "Listening closely to the quiet parts of a track is a good reminder that arrangement matters as much as volume.": DEMO_POSTS[12][1],
    "What album do you return to when you need a little inspiration? I am making a list for the studio.": DEMO_POSTS[13][1],
    "A jacket you already love can make a familiar outfit feel new. Rewearing good pieces is always in style.": DEMO_POSTS[14][1],
    "Getting dressed is easier when the colors work together. I am building this week around navy, cream and one bright accent.": DEMO_POSTS[15][1],
    "Fashion idea: repair the button, mend the seam, and keep the clothes that make you feel like yourself.": DEMO_POSTS[16][1],
    "A comfortable outfit can still feel considered. Fit and fabric do a lot of the work.": DEMO_POSTS[17][1],
    "Trading journal reminder: write down the plan before the chart gets exciting. Risk limits come first.": DEMO_POSTS[18][1],
    "A watchlist is not a signal. I am practicing waiting for my criteria instead of chasing a fast move.": DEMO_POSTS[19][1],
    "Reviewing the week: record the reasoning behind each decision, not just whether it made money.": DEMO_POSTS[20][1],
    "Markets are uncertain. Keep position sizes responsible and never risk money you cannot afford to lose.": DEMO_POSTS[21][1],
    "A steady shot starts before you press record: find your frame, check the light, and take a breath.": DEMO_POSTS[22][1],
    "Editing tip from today: let the scene breathe. Cutting every pause can take the feeling out of an interview.": DEMO_POSTS[23][1],
    "Golden-hour footage is lovely, but a clear story and clean audio make the video worth watching.": DEMO_POSTS[24][1],
    "Behind the scenes: organize clips while the shoot is still fresh. Future-you will be grateful.": DEMO_POSTS[25][1],
    "Learning something difficult gets easier when you break it into a small daily practice you can actually keep.": DEMO_POSTS[26][1],
    "A good question is a learning tool. I keep a note of what I do not understand and look it up after class.": DEMO_POSTS[27][1],
    "Study session idea: explain the concept in your own words, then check which parts still feel unclear.": DEMO_POSTS[28][1],
    "New skill in progress: taking better notes while editing. Short labels make it easier to find a lesson later.": DEMO_POSTS[29][1],
}


IMAGE_BY_POST = {
    "A useful business plan is one you revisit. This week I replaced three guesses with real customer conversations.": "#business #marketing #helpful.jpg",
    "Small teams move faster when everyone knows what a good outcome looks like. Write the goal down before the meeting.": "Be your own boss #business.jpg",
    "First lesson from opening a neighborhood coffee counter: consistency earns trust long before a big launch does.": "CORTEIZ MILLION ORDERS_.jpg",
    "A simple dashboard is only helpful when it answers a real question. Start with the decision, then choose the metric.": "download (12).jpg",
    "Today’s business win was a returning customer by name. It is a better reminder than any spreadsheet.": "download (13).jpg",
    "A quiet early-morning drive is still my favorite way to appreciate a well-balanced car.": "Dear Son_ (@DearS_o_n) on X.jpg",
    "Road-trip checklist: tire pressure, water, a charged phone, and enough time to take the scenic route.": "Sxcrell.jpg",
    "The best interior upgrade is the one that makes every drive more comfortable without adding clutter.": "download (1).jpg",
    "Found a beautiful back road today. Slow down, leave room for cyclists, and enjoy the view.": "download (2).jpg",
    "Car care note: a clean windshield and correctly set mirrors make a bigger difference than people think.": "download (20).jpg",
    "A melody recorded on a phone can still hold the feeling of the whole song. Capture the idea first; polish it later.": "night out in ATL.jpg",
    "Tonight’s session: one drum pattern, a warm bass line, and plenty of space for the vocal.": "download (19).jpg",
    "Listening closely to the quiet parts of a track is a good reminder that arrangement matters as much as volume.": "download (17).jpg",
    "What album do you return to when you need a little inspiration? I am making a list for the studio.": "download (15).jpg",
    "A jacket you already love can make a familiar outfit feel new. Rewearing good pieces is always in style.": "#corteiz #streetwear #denim.jpg",
    "Getting dressed is easier when the colors work together. I am building this week around navy, cream and one bright accent.": "4TF orders out.jpg",
    "Fashion idea: repair the button, mend the seam, and keep the clothes that make you feel like yourself.": "gv gallery_.jpg",
    "A comfortable outfit can still feel considered. Fit and fabric do a lot of the work.": "download (18).jpg",
    "Trading journal reminder: write down the plan before the chart gets exciting. Risk limits come first.": "#setup #table #monitor #trading_.jpg",
    "A watchlist is not a signal. I am practicing waiting for my criteria instead of chasing a fast move.": "download (4).jpg",
    "Reviewing the week: record the reasoning behind each decision, not just whether it made money.": "process _ profits_.jpg",
    "Markets are uncertain. Keep position sizes responsible and never risk money you cannot afford to lose.": "download (5).jpg",
    "A steady shot starts before you press record: find your frame, check the light, and take a breath.": "Sony FX3s.jpg",
    "Editing tip from today: let the scene breathe. Cutting every pause can take the feeling out of an interview.": "AI Photo Editor App UI Design _ Miracle Dark Mode Inspiration.jpg",
    "Golden-hour footage is lovely, but a clear story and clean audio make the video worth watching.": "Soccer Photography, Soccer Photographer, Freelance Soccer Photographer, High School Soccer Pictures, High School Soccer, Orange County CA.jpg",
    "Behind the scenes: organize clips while the shoot is still fresh. Future-you will be grateful.": "sony zv-e10 set up.jpg",
    "Learning something difficult gets easier when you break it into a small daily practice you can actually keep.": "Book Stack _ Vendor.jpg",
    "A good question is a learning tool. I keep a note of what I do not understand and look it up after class.": "good books.jpg",
    "Study session idea: explain the concept in your own words, then check which parts still feel unclear.": "download (6).jpg",
    "New skill in progress: taking better notes while editing. Short labels make it easier to find a lesson later.": "download (7).jpg",
}

IMAGE_BY_POST = {
    LEGACY_CAPTIONS.get(caption, caption): filename
    for caption, filename in IMAGE_BY_POST.items()
}

PROFILE_PHOTOS = {
    "orbit_founder": "Be your own boss #business.jpg",
    "orbit_studio": "AI-Powered Design_ The Future of User Interfaces_ _ by Muzli _ Muzli - Design Inspiration.jpg",
    "orbit_motors": "Sxcrell.jpg",
    "orbit_roadtrip": "Dear Son_ (@DearS_o_n) on X.jpg",
    "orbit_sound": "night out in ATL.jpg",
    "orbit_beats": "download (19).jpg",
    "orbit_style": "#corteiz #streetwear #denim.jpg",
    "orbit_wardrobe": "gv gallery_.jpg",
    "orbit_markets": "#setup #table #monitor #trading_.jpg",
    "orbit_creator": "Sony FX3s.jpg",
    "nomsa_mthembu": "download (16).jpg",
    "sipho_ncube": "download (14).jpg",
    "ayanda_zulu": "download (19).jpg",
    "naledi_molefe": "Be your own boss #business.jpg",
    "kwame_boateng": "download (5).jpg",
    "ama_osei": "night out in ATL.jpg",
    "chidi_okoye": "download (12).jpg",
    "tendai_moyo": "download (18).jpg",
    "makena_otieno": "good books.jpg",
    "thandiwe_sithole": "#corteiz #streetwear #denim.jpg",
    "kevin_washington": "download (1).jpg",
    "olivia_jackson": "download (15).jpg",
    "noah_johnson": "sony zv-e10 set up.jpg",
    "sophia_williams": "turning chats into opportunities.jpg",
    "elijah_bennett": "download (17).jpg",
    "imani_james": "Book Stack _ Vendor.jpg",
    "caleb_mitchell": "download (20).jpg",
    "zoe_davis": "gv gallery_.jpg",
    "mason_clark": "download (2).jpg",
    "harper_morgan": "Sony FX3s.jpg",
}

LEGACY_SEEDED_POST_IMAGES = {
    "A simple dashboard is only helpful when it answers a real question. Start with the decision, then choose the metric.": "AI-Powered Design_ The Future of User Interfaces_ _ by Muzli _ Muzli - Design Inspiration.jpg",
    "Trading journal reminder: write down the plan before the chart gets exciting. Risk limits come first.": "#setup #table #monitor #trading_.jpg",
    "Editing tip from today: let the scene breathe. Cutting every pause can take the feeling out of an interview.": "AI Photo Editor App UI Design _ Miracle Dark Mode Inspiration.jpg",
    "Study session idea: explain the concept in your own words, then check which parts still feel unclear.": "download (2).jpg",
}


class Command(BaseCommand):
    help = "Create 30 sample posts from demo users for the Orbit home feed."

    @transaction.atomic
    def handle(self, *args, **options):
        if len(DEMO_POSTS) != 30:
            raise ValueError(f"Expected exactly 30 demo posts, found {len(DEMO_POSTS)}.")

        image_directory = Path(settings.BASE_DIR) / "images"
        source_images = set(IMAGE_BY_POST.values()) | set(PROFILE_PHOTOS.values())
        missing_images = sorted(name for name in source_images if not (image_directory / name).is_file())
        if missing_images:
            raise FileNotFoundError(f"Seed images not found in {image_directory}: {', '.join(missing_images)}")

        creators = {}
        for old_username, (username, first_name, last_name, bio) in CREATORS.items():
            old_user = User.objects.filter(username=old_username).first()
            user = User.objects.filter(username=username).first()
            if old_user and user and old_user.pk != user.pk:
                raise CommandError(
                    f"Cannot rename demo account @{old_username}: @{username} is already in use."
                )
            if (
                not old_user
                and user
                and not user.is_demo_account
                and not user.email.endswith("@demo.orbit.invalid")
            ):
                raise CommandError(
                    f"Cannot create demo account @{username}: that username belongs to a real account."
                )
            created = False
            if old_user:
                user = old_user
                user.username = username
                user.email = f"{username}@demo.orbit.invalid"
            elif not user:
                user = User(
                    username=username,
                    email=f"{username}@demo.orbit.invalid",
                )
                created = True
            user.first_name = first_name
            user.last_name = last_name
            user.bio = bio
            user.is_demo_account = True
            if created:
                user.set_unusable_password()
            user.save()
            creators[old_username] = user
            creators[username] = user

        for username, (first_name, last_name, bio) in SUPPORTERS.items():
            user = User.objects.filter(username=username).first()
            if user and not user.is_demo_account:
                raise CommandError(
                    f"Cannot create demo account @{username}: that username belongs to a real account."
                )
            if not user:
                user = User(
                    username=username,
                    email=f"{username}@demo.orbit.invalid",
                    is_demo_account=True,
                )
                user.set_unusable_password()
            user.first_name = first_name
            user.last_name = last_name
            user.bio = bio
            user.is_demo_account = True
            user.save()
            creators[username] = user

        profile_count = 0
        for old_username, image_name in PROFILE_PHOTOS.items():
            user = creators[old_username]
            if user.profile_picture:
                continue
            avatar_bytes = self.make_avatar(image_directory / image_name)
            user.profile_picture.save(
                f"{user.username}.jpg",
                ContentFile(avatar_bytes),
                save=True,
            )
            profile_count += 1

        ensure_demo_followers(list(User.objects.filter(is_demo_account=True).order_by("pk")))

        created_count = 0
        updated_count = 0
        legacy_captions = {new_caption: old_caption for old_caption, new_caption in LEGACY_CAPTIONS.items()}
        for username, text in DEMO_POSTS:
            author = creators[username]
            legacy_caption = legacy_captions.get(text)
            post = author.posts.filter(text__in=[text, legacy_caption]).order_by("pk").first()
            created = post is None
            if created:
                post = Post.objects.create(author=author, text=text)
            if created:
                created_count += 1
            post_changed = False
            if post.text != text:
                post.text = text
                post_changed = True

            image_name = IMAGE_BY_POST.get(text)
            legacy_image_name = LEGACY_SEEDED_POST_IMAGES.get(legacy_caption)
            is_legacy_seed_image = (
                post.image
                and legacy_image_name
                and self.normalized_name(Path(post.image.name).name).startswith(
                    self.normalized_name(legacy_image_name)[:40]
                )
            )
            image_path = image_directory / image_name if image_name else None
            expected_image_name = self.normalized_name(f"{post.pk}-{image_path.name}") if image_path else None
            is_expected_seed_image = (
                post.image
                and expected_image_name
                and self.normalized_name(Path(post.image.name).name).startswith(expected_image_name[:40])
            )
            is_seed_image = post.image and "demo_posts/" in post.image.name.replace("\\", "/")
            if image_path and (
                not post.image
                or (is_seed_image and not is_expected_seed_image)
                or (is_legacy_seed_image and not is_expected_seed_image)
            ):
                with image_path.open("rb") as image_file:
                    post.image.save(
                        f"demo_posts/{post.pk}-{image_path.name}",
                        ContentFile(image_file.read()),
                        save=False,
                    )
                updated_count += 1
                post_changed = True
            if post_changed:
                post.save()

        self.stdout.write(
            self.style.SUCCESS(
                f"Demo feed ready: {created_count} new posts added, "
                f"{updated_count} post photos added and {profile_count} profile pictures added; "
                f"{Post.objects.filter(author__username__in=[identity[0] for identity in CREATORS.values()]).count()} demo posts total."
            )
        )

    @staticmethod
    def make_avatar(image_path):
        with Image.open(image_path) as source:
            image = ImageOps.fit(source.convert("RGB"), (512, 512), method=Image.Resampling.LANCZOS)
        buffer = BytesIO()
        image.save(buffer, format="JPEG", quality=88, optimize=True)
        return buffer.getvalue()

    @staticmethod
    def normalized_name(filename):
        return "".join(character.lower() for character in Path(filename).stem if character.isalnum())
