import json
import random

from django.contrib import messages
from django.contrib.auth import login

from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Count, Exists, OuterRef, Prefetch, Q
from django.http import HttpResponseNotAllowed, JsonResponse
from django.views.decorators.http import require_GET, require_POST
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme

from .demo_activity import ensure_demo_followers
from .forms import CommentForm, DirectMessageForm, PostForm, ProfileForm, RegistrationForm
from .models import (
    CallSession,
    CallSignal,
    Comment,
    CommentLike,
    DirectMessage,
    Follow,
    Like,
    Post,
    User,
)

QUICK_REPLIES = (
    "Hey {name}, thanks for reaching out! Hope you're having a good day. I'll get back to you soon.",
    "Hi {name}! Lovely to hear from you. Thanks for the message - I'll reply properly as soon as I can.",
    "Hey there, {name}! Thanks for your message. I appreciate you checking in and will get back to you soon.",
    "Thanks for the message, {name}! Hope everything's going well with you. I'll be in touch soon.",
)


def friendly_quick_reply(user):
    name = user.first_name.strip() or user.username
    return random.choice(QUICK_REPLIES).format(name=name)


def comments_for_user(user):
    return Comment.objects.select_related("author").annotate(
        like_count=Count("likes", distinct=True),
        liked_by_user=Exists(
            CommentLike.objects.filter(comment_id=OuterRef("pk"), user=user)
        ),
    )


def posts_for_user(user, queryset=None):
    if queryset is None:
        queryset = Post.objects.all()
    repost_target = Q(repost_of_id=OuterRef("pk")) | Q(repost_of_id=OuterRef("repost_of_id"))
    return queryset.select_related("author", "repost_of", "repost_of__author").prefetch_related(
        Prefetch("comments", queryset=comments_for_user(user)),
        Prefetch("repost_of__comments", queryset=comments_for_user(user)),
    ).annotate(
        like_count=Count("likes", distinct=True) + Count("repost_of__likes", distinct=True),
        liked_by_user=Exists(
            Like.objects.filter(
                Q(post_id=OuterRef("pk")) | Q(post_id=OuterRef("repost_of_id")),
                user=user,
            )
        ),
        repost_count=Count("reposts", distinct=True) + Count("repost_of__reposts", distinct=True),
        reposted_by_user=Exists(Post.objects.filter(author=user).filter(repost_target)),
    )


def comment_forms_for_posts(posts):
    return {
        post.repost_of_id or post.pk: CommentForm()
        for post in posts
    }


def register(request):
    if request.user.is_authenticated:
        return redirect("home")
    form = RegistrationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save()
        demo_users = list(User.objects.filter(is_demo_account=True).order_by("pk"))
        if demo_users:
            ensure_demo_followers(demo_users)
        login(request, user)
        return redirect("home")
    return render(request, "social/register.html", {"form": form})


@login_required
def home(request):
    post_form = PostForm(request.POST or None, request.FILES or None)
    if request.method == "POST":
        if post_form.is_valid():
            post = post_form.save(commit=False)
            post.author = request.user
            post.demo_like_started_at = timezone.now()
            post.save()
            messages.success(request, "Your post is published.")
            return redirect("home")

    posts = posts_for_user(request.user).order_by("?")
    return render(
        request,
        "social/home.html",
        {"posts": posts, "post_form": post_form, "comment_forms": comment_forms_for_posts(posts)},
    )


@login_required
def explore(request):
    query = request.GET.get("q", "").strip()
    users = User.objects.exclude(pk=request.user.pk).order_by("username")
    if query:
        users = users.filter(username__icontains=query)
    posts = posts_for_user(request.user, Post.objects.exclude(author=request.user))
    return render(
        request,
        "social/explore.html",
        {
            "users": users,
            "posts": posts,
            "query": query,
            "comment_forms": comment_forms_for_posts(posts),
        },
    )


@login_required
def inbox(request):
    conversation_users = User.objects.filter(
        Q(sent_messages__recipient=request.user)
        | Q(received_messages__sender=request.user)
    ).distinct().order_by("username")
    people = User.objects.exclude(pk=request.user.pk).order_by("username")
    return render(
        request,
        "social/inbox.html",
        {"conversation_users": conversation_users, "people": people},
    )


@login_required
def conversation(request, username):
    other_user = get_object_or_404(User, username=username)
    if other_user == request.user:
        messages.error(request, "You cannot start a conversation with yourself.")
        return redirect("inbox")

    form = DirectMessageForm(request.POST or None)
    if request.method == "POST":
        if form.is_valid():
            with transaction.atomic():
                message = form.save(commit=False)
                message.sender = request.user
                message.recipient = other_user
                message.save()
                DirectMessage.objects.create(
                    sender=other_user,
                    recipient=request.user,
                    content=friendly_quick_reply(request.user),
                    is_automatic=True,
                )
            return redirect("conversation", username=other_user.username)

    chat_messages = DirectMessage.objects.filter(
        Q(sender=request.user, recipient=other_user)
        | Q(sender=other_user, recipient=request.user)
    ).select_related("sender", "recipient")
    return render(
        request,
        "social/conversation.html",
        {
            "other_user": other_user,
            "chat_messages": chat_messages,
            "form": form,
        },
    )


def parse_call_request(request):
    try:
        data = json.loads(request.body)
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None
    return data if isinstance(data, dict) else None


def call_error(detail, status=400):
    return JsonResponse({"error": detail}, status=status)


@login_required
@require_POST
def start_call(request, username):
    callee = get_object_or_404(User, username=username)
    if callee == request.user:
        return call_error("You cannot call yourself.")

    data = parse_call_request(request)
    if data is None:
        return call_error("Send a valid JSON request.")
    call_type = data.get("call_type")
    offer = data.get("offer")
    if call_type not in CallSession.CallType.values:
        return call_error("Choose a voice or video call.")
    if (
        not isinstance(offer, dict)
        or offer.get("type") != "offer"
        or not isinstance(offer.get("sdp"), str)
        or len(offer["sdp"]) > 100_000
    ):
        return call_error("A valid WebRTC offer is required.")

    participants = Q(caller=request.user, callee=callee) | Q(caller=callee, callee=request.user)
    with transaction.atomic():
        if CallSession.objects.filter(
            participants,
            status__in=[CallSession.Status.RINGING, CallSession.Status.ACTIVE],
        ).exists():
            return call_error("There is already an active call between these users.", status=409)
        call = CallSession.objects.create(caller=request.user, callee=callee, call_type=call_type)
        offer_signal = CallSignal.objects.create(
            call=call,
            sender=request.user,
            signal_type=CallSignal.SignalType.OFFER,
            payload=offer,
        )

    return JsonResponse({"call_id": call.pk, "last_signal_id": offer_signal.pk}, status=201)


@login_required
@require_GET
def poll_calls(request, username):
    other_user = get_object_or_404(User, username=username)
    if other_user == request.user:
        return call_error("You cannot call yourself.")

    call = CallSession.objects.filter(
        Q(caller=request.user, callee=other_user)
        | Q(caller=other_user, callee=request.user),
        status__in=[CallSession.Status.RINGING, CallSession.Status.ACTIVE],
    ).select_related("caller", "callee").first()
    if call is None:
        return JsonResponse({"call": None})

    offer_signal = call.signals.filter(signal_type=CallSignal.SignalType.OFFER).first()
    latest_signal = call.signals.order_by("-pk").first()
    return JsonResponse(
        {
            "call": {
                "id": call.pk,
                "caller_id": call.caller_id,
                "caller_username": call.caller.username,
                "callee_id": call.callee_id,
                "call_type": call.call_type,
                "status": call.status,
                "offer": offer_signal.payload if offer_signal else None,
                "offer_signal_id": offer_signal.pk if offer_signal else 0,
                "last_signal_id": latest_signal.pk if latest_signal else 0,
            }
        }
    )


@login_required
@require_GET
def poll_call_signals(request, call_id):
    call = get_object_or_404(CallSession, pk=call_id)
    if request.user.pk not in (call.caller_id, call.callee_id):
        return call_error("You are not a participant in this call.", status=403)
    after_value = request.GET.get("after", "0")
    if not after_value.isdecimal():
        return call_error("The signal cursor must be a non-negative integer.")
    signals = call.signals.filter(pk__gt=int(after_value)).select_related("sender")
    return JsonResponse(
        {
            "status": call.status,
            "signals": [
                {
                    "id": signal.pk,
                    "sender_id": signal.sender_id,
                    "type": signal.signal_type,
                    "payload": signal.payload,
                }
                for signal in signals
            ],
        }
    )


@login_required
@require_POST
def send_call_signal(request, call_id):
    call = get_object_or_404(CallSession, pk=call_id)
    if request.user.pk not in (call.caller_id, call.callee_id):
        return call_error("You are not a participant in this call.", status=403)

    data = parse_call_request(request)
    if data is None:
        return call_error("Send a valid JSON request.")
    signal_type = data.get("type")
    payload = data.get("payload", {})
    if signal_type not in {
        CallSignal.SignalType.ANSWER,
        CallSignal.SignalType.ICE,
        CallSignal.SignalType.END,
        CallSignal.SignalType.REJECT,
    } or not isinstance(payload, dict):
        return call_error("The call signal is invalid.")
    if len(json.dumps(payload)) > 100_000:
        return call_error("The call signal is too large.")
    if signal_type == CallSignal.SignalType.ANSWER and (
        request.user.pk != call.callee_id
        or payload.get("type") != "answer"
        or not isinstance(payload.get("sdp"), str)
    ):
        return call_error("Only the recipient can send a valid call answer.")
    if signal_type == CallSignal.SignalType.REJECT and request.user.pk != call.callee_id:
        return call_error("Only the recipient can reject a call.")
    if signal_type == CallSignal.SignalType.ICE and not isinstance(payload.get("candidate"), str):
        return call_error("A valid ICE candidate is required.")
    if signal_type in {CallSignal.SignalType.END, CallSignal.SignalType.REJECT} and call.status in {
        CallSession.Status.ENDED,
        CallSession.Status.REJECTED,
    }:
        return call_error("This call has already ended.", status=409)
    if signal_type == CallSignal.SignalType.ANSWER and call.status != CallSession.Status.RINGING:
        return call_error("This call is no longer waiting for an answer.", status=409)

    with transaction.atomic():
        if signal_type == CallSignal.SignalType.ANSWER:
            call.status = CallSession.Status.ACTIVE
            call.save(update_fields=["status", "updated_at"])
        elif signal_type == CallSignal.SignalType.END:
            call.status = CallSession.Status.ENDED
            call.save(update_fields=["status", "updated_at"])
        elif signal_type == CallSignal.SignalType.REJECT:
            call.status = CallSession.Status.REJECTED
            call.save(update_fields=["status", "updated_at"])
        signal = CallSignal.objects.create(
            call=call,
            sender=request.user,
            signal_type=signal_type,
            payload=payload,
        )
    return JsonResponse({"signal_id": signal.pk, "status": call.status}, status=201)


@login_required
def my_profile(request):
    return redirect("profile", username=request.user.username)


@login_required
def profile(request, username):
    profile_user = get_object_or_404(User, username=username)
    is_owner = profile_user == request.user
    profile_form = ProfileForm(
        request.POST or None,
        request.FILES or None,
        instance=request.user if is_owner else None,
    )
    if request.method == "POST":
        if not is_owner:
            return HttpResponseNotAllowed(["GET"])
        if profile_form.is_valid():
            profile_form.save()
            messages.success(request, "Your profile has been updated.")
            return redirect("profile", username=request.user.username)

    is_following = (
        Follow.objects.filter(follower=request.user, following=profile_user).exists()
        if not is_owner
        else False
    )
    posts = posts_for_user(request.user, profile_user.posts.all())
    return render(
        request,
        "social/profile.html",
        {
            "profile_user": profile_user,
            "is_owner": is_owner,
            "is_following": is_following,
            "posts": posts,
            "profile_form": profile_form,
            "comment_forms": comment_forms_for_posts(posts),
        },
    )


@login_required
def post_detail(request, post_id):
    post = get_object_or_404(posts_for_user(request.user), pk=post_id)
    target_post_id = post.repost_of_id or post.pk
    return render(
        request,
        "social/post_detail.html",
        {
            "posts": [post],
            "comment_forms": {target_post_id: CommentForm()},
        },
    )


@login_required
def toggle_follow(request, username):
    if request.method != "POST":
        return HttpResponseNotAllowed(["POST"])
    target = get_object_or_404(User, username=username)
    if target == request.user:
        messages.error(request, "You cannot follow yourself.")
    else:
        follow, created = Follow.objects.get_or_create(follower=request.user, following=target)
        if not created:
            follow.delete()
        messages.success(request, f"You are now {'following' if created else 'unfollowing'} @{target.username}.")
    return redirect("profile", username=target.username)


@login_required
def toggle_like(request, post_id):
    if request.method != "POST":
        return HttpResponseNotAllowed(["POST"])
    post = get_object_or_404(Post, pk=post_id)
    post = post.repost_of or post
    with transaction.atomic():
        like, created = Like.objects.get_or_create(post=post, user=request.user)
        if not created:
            like.delete()

    if "application/json" in request.headers.get("Accept", ""):
        return JsonResponse(
            {
                "liked": created,
                "like_count": post.likes.count(),
            }
        )

    next_url = request.POST.get("next", "")
    if url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}):
        return redirect(next_url)
    return redirect("home")


@login_required
def toggle_comment_like(request, comment_id):
    if request.method != "POST":
        return HttpResponseNotAllowed(["POST"])
    comment = get_object_or_404(Comment, pk=comment_id)
    with transaction.atomic():
        comment_like, created = CommentLike.objects.get_or_create(
            comment=comment,
            user=request.user,
        )
        if not created:
            comment_like.delete()

    if "application/json" in request.headers.get("Accept", ""):
        return JsonResponse(
            {
                "liked": created,
                "like_count": comment.likes.count(),
            }
        )

    next_url = request.POST.get("next", "")
    if url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}):
        return redirect(next_url)
    return redirect("home")


@login_required
def repost_post(request, post_id):
    if request.method != "POST":
        return HttpResponseNotAllowed(["POST"])
    post = get_object_or_404(Post, pk=post_id)
    post = post.repost_of or post
    if post.author_id == request.user.pk:
        if "application/json" in request.headers.get("Accept", ""):
            return JsonResponse(
                {"reposted": False, "detail": "You cannot repost your own post."},
                status=400,
            )
        messages.error(request, "You cannot repost your own post.")
    else:
        _, created = Post.objects.get_or_create(author=request.user, repost_of=post)
        if "application/json" in request.headers.get("Accept", ""):
            return JsonResponse(
                {
                    "reposted": True,
                    "created": created,
                    "repost_count": post.reposts.count(),
                }
            )
        if created:
            messages.success(request, "Post reposted to your profile and feed.")
        else:
            messages.info(request, "You have already reposted this post.")

    next_url = request.POST.get("next", "")
    if url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}):
        return redirect(next_url)
    return redirect("home")


@login_required
def add_comment(request, post_id):
    if request.method != "POST":
        return HttpResponseNotAllowed(["POST"])
    post = get_object_or_404(Post, pk=post_id)
    post = post.repost_of or post
    form = CommentForm(request.POST)
    if form.is_valid():
        comment = form.save(commit=False)
        comment.post = post
        comment.author = request.user
        comment.save()
    else:
        messages.error(request, "Enter a comment of up to 300 characters.")

    next_url = request.POST.get("next", "")
    if url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}):
        return redirect(next_url)
    if request.path.startswith("/profile/"):
        return redirect("profile", username=post.author.username)
    return redirect(reverse("home"))
