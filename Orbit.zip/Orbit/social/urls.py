from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("explore/", views.explore, name="explore"),
    path("messages/", views.inbox, name="inbox"),
    path("messages/<str:username>/", views.conversation, name="conversation"),
    path("messages/<str:username>/calls/", views.poll_calls, name="poll_calls"),
    path("messages/<str:username>/calls/start/", views.start_call, name="start_call"),
    path("messages/calls/<int:call_id>/signals/", views.poll_call_signals, name="poll_call_signals"),
    path("messages/calls/<int:call_id>/signals/send/", views.send_call_signal, name="send_call_signal"),
    path("accounts/register/", views.register, name="register"),
    path("profile/", views.my_profile, name="my_profile"),
    path("profile/<str:username>/", views.profile, name="profile"),
    path("profile/<str:username>/follow/", views.toggle_follow, name="toggle_follow"),
    path("posts/<int:post_id>/", views.post_detail, name="post_detail"),
    path("posts/<int:post_id>/like/", views.toggle_like, name="toggle_like"),
    path("posts/<int:post_id>/repost/", views.repost_post, name="repost_post"),
    path("comments/<int:comment_id>/like/", views.toggle_comment_like, name="toggle_comment_like"),
    path("posts/<int:post_id>/comments/", views.add_comment, name="add_comment"),
]
