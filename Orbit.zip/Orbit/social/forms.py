from django import forms
from django.contrib.auth.forms import UserCreationForm

from .models import Comment, DirectMessage, Post, User


class RegistrationForm(UserCreationForm):
    email = forms.EmailField()

    class Meta(UserCreationForm.Meta):
        model = User
        fields = ("username", "email")


class ProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ("bio", "profile_picture")
        widgets = {"bio": forms.Textarea(attrs={"rows": 3, "maxlength": 160})}

    def clean_profile_picture(self):
        picture = self.cleaned_data.get("profile_picture")
        if picture and picture.size > 5 * 1024 * 1024:
            raise forms.ValidationError("Profile pictures must be 5 MB or smaller.")
        return picture


class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ("text", "image")
        widgets = {
            "text": forms.Textarea(
                attrs={
                    "rows": 3,
                    "maxlength": 500,
                    "placeholder": "Write a caption that describes your photo...",
                }
            ),
        }

    def clean(self):
        cleaned_data = super().clean()
        if not cleaned_data.get("text") and not cleaned_data.get("image"):
            raise forms.ValidationError("Write something or add a photo before posting.")
        return cleaned_data

    def clean_image(self):
        image = self.cleaned_data.get("image")
        if image and image.size > 8 * 1024 * 1024:
            raise forms.ValidationError("Post photos must be 8 MB or smaller.")
        return image


class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ("text",)
        widgets = {"text": forms.TextInput(attrs={"maxlength": 300, "placeholder": "Write a comment..."})}


class DirectMessageForm(forms.ModelForm):
    class Meta:
        model = DirectMessage
        fields = ("content",)
        widgets = {
            "content": forms.Textarea(
                attrs={"rows": 3, "maxlength": 1000, "placeholder": "Write a message..."}
            )
        }
