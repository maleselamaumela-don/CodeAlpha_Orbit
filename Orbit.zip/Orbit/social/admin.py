from django.contrib import admin
from django.contrib.auth.admin import UserAdmin

from .models import Comment, Follow, Post, User


@admin.register(User)
class OrbitUserAdmin(UserAdmin):
    fieldsets = UserAdmin.fieldsets + (
        ("Orbit profile", {"fields": ("bio", "profile_picture")}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        ("Contact", {"fields": ("email",)}),
        ("Orbit profile", {"fields": ("bio", "profile_picture")}),
    )
    list_display = ("username", "email", "is_staff")
    search_fields = ("username", "email")


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ("author", "created_at")
    search_fields = ("author__username", "text")
    list_filter = ("created_at",)


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ("author", "post", "created_at")
    search_fields = ("author__username", "text")


@admin.register(Follow)
class FollowAdmin(admin.ModelAdmin):
    list_display = ("follower", "following", "created_at")
    search_fields = ("follower__username", "following__username")
