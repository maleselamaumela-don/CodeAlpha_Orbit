/* =====================================================
   explore.js — the Explore page
   - search usernames
   - suggested users with follow buttons
   - trending topics (filter posts by topic)
   - browse popular posts
   ===================================================== */

document.addEventListener("DOMContentLoaded", () => {
  if (document.body.dataset.page !== "explore") return;
  if (!initPage("explore")) return;

  const searchInput = document.getElementById("userSearch");
  const userList = document.getElementById("suggestedUsers");
  const postsContainer = document.getElementById("explorePosts");

  // A trending topic can be chosen with ?topic=%23Travel in the address
  const activeTopic = new URLSearchParams(window.location.search).get("topic") || "";

  /* ---------- Suggested users (filtered by the search box) ---------- */
  function renderUsers() {
    // Remove a leading "@" and ignore capital letters
    const query = searchInput.value.trim().replace(/^@/, "").toLowerCase();
    const matches = getDiscoverableUsers().filter((user) => user.username.toLowerCase().includes(query));

    if (matches.length === 0) {
      userList.innerHTML = '<li class="empty-state">No users found for "' + escapeHtml(searchInput.value.trim()) + '".</li>';
      return;
    }
    userList.innerHTML = matches.map(renderUserRow).join("");
  }

  /* ---------- Popular posts (most likes first, optional topic filter) ---------- */
  function renderPosts() {
    let posts = getPosts().sort((a, b) => b.likedBy.length - a.likedBy.length);
    if (activeTopic) {
      posts = posts.filter((post) => post.text.toLowerCase().includes(activeTopic.toLowerCase()));
    }
    renderFeed(postsContainer, posts, activeTopic ? "No posts found for " + activeTopic + " yet." : "No posts to explore yet.");
  }

  /* ---------- Start ---------- */
  if (activeTopic) {
    document.getElementById("topicBanner").classList.remove("hidden");
    document.getElementById("topicName").textContent = activeTopic;
  }
  renderUsers();
  renderPosts();
  renderTrending(document.getElementById("trendingList"));
  attachPostEvents(postsContainer, renderPosts);

  searchInput.addEventListener("input", renderUsers);   // filter as you type

  // The "Search" link in the navigation bar jumps to the search box
  function focusSearchIfRequested() {
    if (window.location.hash === "#search") {
      document.getElementById("search").scrollIntoView({ behavior: "smooth" });
      searchInput.focus();
    }
  }
  focusSearchIfRequested();
  window.addEventListener("hashchange", focusSearchIfRequested);
});
