/* =====================================================
   auth.js — login, registration, password toggle, logout
   IMPORTANT: This is a DEMONSTRATION only. There is no
   backend or database, so this is NOT real authentication.
   Accounts are saved in the browser's localStorage and the
   password is stored as plain text. Never use a real password.
   ===================================================== */

/* ---------- Logout (works from every page) ---------- */
function logout() {
  localStorage.removeItem(KEYS.session);   // forget who is logged in
  window.location.href = "login.html";     // back to the login screen
}

// The Logout button is created by app.js, so we listen on the whole document
document.addEventListener("click", (event) => {
  if (event.target.closest("#logoutBtn")) logout();
});

/* ---------- Helpers for form messages ---------- */

// Shows (or clears) an error message under an input
function setFieldError(input, message) {
  const errorBox = document.getElementById(input.id + "Error");
  if (errorBox) errorBox.textContent = message;
  input.classList.toggle("invalid", message !== "");
  input.setAttribute("aria-invalid", message !== "");
}

// Very basic email check: something@something.something
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/* ---------- Show / hide password buttons ---------- */
function initPasswordToggles() {
  document.querySelectorAll(".toggle-password").forEach((button) => {
    button.addEventListener("click", () => {
      const input = document.getElementById(button.dataset.target);
      const isHidden = input.type === "password";
      input.type = isHidden ? "text" : "password";
      button.textContent = isHidden ? "Hide" : "Show";
      button.setAttribute("aria-label", isHidden ? "Hide password" : "Show password");
    });
  });
}

/* ---------- Login page ---------- */
function initLoginPage() {
  const form = document.getElementById("loginForm");
  const idInput = document.getElementById("loginId");
  const passwordInput = document.getElementById("loginPassword");
  const formMessage = document.getElementById("formMessage");

  form.addEventListener("submit", (event) => {
    event.preventDefault();               // stop the page from reloading
    formMessage.textContent = "";
    let isValid = true;

    // 1. Check for empty fields
    const identifier = idInput.value.trim();
    const password = passwordInput.value;
    setFieldError(idInput, identifier === "" ? "Please enter your username or email." : "");
    setFieldError(passwordInput, password === "" ? "Please enter your password." : "");
    if (identifier === "" || password === "") isValid = false;
    if (!isValid) return;

    // 2. Look for a matching demo account
    const account = getAccounts().find((item) =>
      (item.username.toLowerCase() === identifier.toLowerCase() ||
       item.email.toLowerCase() === identifier.toLowerCase()) &&
      item.password === password
    );

    if (!account) {
      formMessage.textContent = "Incorrect username/email or password.";
      return;
    }

    // 3. Success: remember the user and go to the home feed
    saveData(KEYS.session, { username: account.username });
    window.location.href = "index.html";
  });
}

/* ---------- Registration page ---------- */
function initRegisterPage() {
  const form = document.getElementById("registerForm");
  const usernameInput = document.getElementById("regUsername");
  const emailInput = document.getElementById("regEmail");
  const passwordInput = document.getElementById("regPassword");
  const confirmInput = document.getElementById("regConfirm");
  const formMessage = document.getElementById("formMessage");

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    formMessage.textContent = "";

    const username = usernameInput.value.trim();
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    const confirm = confirmInput.value;

    // Work out an error message for each field ("" means no error)
    const usernameTaken =
      getAccounts().some((a) => a.username.toLowerCase() === username.toLowerCase()) ||
      SAMPLE_USERS.some((u) => u.username.toLowerCase() === username.toLowerCase());

    let usernameError = "";
    if (username === "") usernameError = "Please choose a username.";
    else if (!/^[A-Za-z0-9_.]{3,20}$/.test(username)) usernameError = "Use 3-20 letters, numbers, dots or underscores.";
    else if (usernameTaken) usernameError = "That username is already taken.";

    let emailError = "";
    if (email === "") emailError = "Please enter your email address.";
    else if (!isValidEmail(email)) emailError = "Please enter a valid email (like name@example.com).";
    else if (getAccounts().some((a) => a.email.toLowerCase() === email.toLowerCase())) emailError = "That email is already registered.";

    let passwordError = "";
    if (password === "") passwordError = "Please create a password.";
    else if (password.length < 6) passwordError = "Password must be at least 6 characters.";

    let confirmError = "";
    if (confirm === "") confirmError = "Please confirm your password.";
    else if (confirm !== password) confirmError = "Passwords do not match.";

    // Show all the messages
    setFieldError(usernameInput, usernameError);
    setFieldError(emailInput, emailError);
    setFieldError(passwordInput, passwordError);
    setFieldError(confirmInput, confirmError);

    // Stop if anything is wrong
    if (usernameError || emailError || passwordError || confirmError) return;

    // Everything is fine: create the demo account
    const accounts = getAccounts();
    accounts.push({ username, email, password, bio: "Hello! I just joined Orbit. 👋", followers: 0 });
    saveData(KEYS.accounts, accounts);

    // Give the new user a welcome notification, then log them in
    addNotification(username, "system", "Orbit", "Welcome to Orbit! Share your first post on the Home page.");
    saveData(KEYS.session, { username });
    window.location.href = "index.html";
  });
}

/* ---------- Start-up for login and register pages ---------- */
document.addEventListener("DOMContentLoaded", () => {
  const page = document.body.dataset.page;
  if (page !== "login" && page !== "register") return;

  seedDemoData();
  // Already logged in? Go straight to the home page.
  if (getCurrentUser()) {
    window.location.replace("index.html");
    return;
  }
  initPasswordToggles();
  if (page === "login") initLoginPage();
  if (page === "register") initRegisterPage();
});
