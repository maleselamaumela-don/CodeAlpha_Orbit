document.addEventListener("click", async (event) => {
  const button = event.target.closest("[data-share-url]");
  if (!button) return;

  const status = button.querySelector(".share-status");
  const shareData = {
    title: button.dataset.shareTitle,
    url: button.dataset.shareUrl,
  };

  try {
    if (navigator.share) {
      await navigator.share(shareData);
      return;
    }
    await navigator.clipboard.writeText(shareData.url);
    status.textContent = "Link copied";
  } catch (error) {
    if (error.name === "AbortError") return;
    status.textContent = "Could not share link";
  }
});

document.addEventListener("submit", async (event) => {
  const form = event.target.closest("form[data-post-action]");
  if (!form || form.dataset.busy === "true") return;

  event.preventDefault();
  const button = form.querySelector('button[type="submit"]');
  const action = form.dataset.postAction;
  form.dataset.busy = "true";
  if (button) button.disabled = true;

  try {
    const response = await fetch(form.action, {
      method: "POST",
      body: new FormData(form),
      headers: { Accept: "application/json" },
      credentials: "same-origin",
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.detail || "Could not update the post.");

    if (action === "like") {
      const likeButton = form.querySelector("button");
      likeButton.classList.toggle("liked", result.liked);
      likeButton.setAttribute("aria-pressed", String(result.liked));
      likeButton.setAttribute(
        "aria-label",
        `${result.liked ? "Unlike" : "Like"} this post`,
      );
      likeButton.querySelector(".like-label").textContent = result.liked ? "Liked" : "Like";
      likeButton.querySelector(".like-count").textContent = result.like_count;
      if (button) button.disabled = false;
    } else if (action === "comment-like") {
      const likeButton = form.querySelector("button");
      likeButton.classList.toggle("liked", result.liked);
      likeButton.setAttribute("aria-pressed", String(result.liked));
      likeButton.setAttribute(
        "aria-label",
        `${result.liked ? "Unlike" : "Like"} comment`,
      );
      likeButton.querySelector(".comment-like-label").textContent = result.liked ? "Liked" : "Like";
      likeButton.querySelector(".comment-like-count").textContent = result.like_count;
      if (button) button.disabled = false;
    } else if (action === "repost") {
      const repostButton = form.querySelector("button");
      repostButton.querySelector(".repost-label-text").textContent = "Reposted";
      repostButton.querySelector(".repost-count").textContent = result.repost_count;
      repostButton.setAttribute("aria-label", "Already reposted");
      repostButton.disabled = true;
    }
    form.dataset.busy = "false";
  } catch (error) {
    form.dataset.busy = "false";
    if (button) button.disabled = false;
    HTMLFormElement.prototype.submit.call(form);
  }
});
