/* =====================================================
   posts.js — everything about posts
   - drawing a post card
   - like, comment, share, copy, delete
   - creating a new post (with image preview)
   - the Home page start-up code
   Used by: index.html, explore.html, profile.html
   ===================================================== */

/* ---------- Reading and saving posts ---------- */
function getPosts() {
  return loadData(KEYS.posts, []);
}

function savePosts(posts) {
  return saveData(KEYS.posts, posts);
}

function getPostsNewestFirst() {
  return getPosts().slice().sort((a, b) => b.time - a.time);
}

/* =====================================================
   Drawing posts on the page
   ===================================================== */

// HTML for the list of comments under a post
function renderComments(comments) {
  if (comments.length === 0) {
    return '<li class="muted small">No comments yet. Be the first!</li>';
  }
  return comments.map((comment) => `
    <li class="comment">
      <img class="avatar avatar-xs" src="${avatarUrl(comment.author)}" alt="">
      <div class="comment-body">
        <strong>@${escapeHtml(comment.author)}</strong>
        <span class="muted small">${timeAgo(comment.time)}</span>
        <p>${escapeHtml(comment.text)}</p>
      </div>
    </li>`).join("");
}

// HTML for one complete post card
function renderPostCard(post, currentUser) {
  const author = escapeHtml(post.author);
  const profileLink = "profile.html?user=" + encodeURIComponent(post.author);
  const liked = post.likedBy.includes(currentUser.username);
  const isOwnPost = post.author === currentUser.username;

  return `
  <article class="card post" id="post-${post.id}" data-post-id="${post.id}">
    <header class="post-header">
      <a href="${profileLink}"><img class="avatar" src="${avatarUrl(post.author)}" alt="Profile picture of ${author}"></a>
      <div class="post-meta">
        <a class="post-author" href="${profileLink}">@${author}</a>
        <span class="muted small">${timeAgo(post.time)}</span>
      </div>
      <div class="menu-wrap">
        <button type="button" class="icon-btn" data-action="menu" aria-label="More actions" aria-haspopup="true">${icon("dots")}</button>
        <div class="menu hidden" role="menu">
          <button type="button" data-action="copy" role="menuitem">Copy text</button>
          <a href="${profileLink}" role="menuitem">View profile</a>
          ${isOwnPost ? '<button type="button" class="danger" data-action="delete" role="menuitem">Delete post</button>' : ""}
        </div>
      </div>
    </header>

    ${post.text ? `<p class="post-text">${escapeHtml(post.text)}</p>` : ""}
    ${post.image ? `<img class="post-image" src="${post.image}" alt="Picture shared by ${author}" loading="lazy">` : ""}

    <div class="post-actions">
      <button type="button" class="action-btn ${liked ? "liked" : ""}" data-action="like" aria-pressed="${liked}" aria-label="Like">
        ${icon("heart")}<span class="like-count">${post.likedBy.length}</span>
      </button>
      <button type="button" class="action-btn" data-action="comment-toggle" aria-expanded="false" aria-label="Comments">
        ${icon("comment")}<span class="comment-count">${post.comments.length}</span>
      </button>
      <button type="button" class="action-btn" data-action="share" aria-label="Share">
        ${icon("share")}<span>Share</span>
      </button>
    </div>

    <section class="comments hidden" aria-label="Comments">
      <ul class="comment-list">${renderComments(post.comments)}</ul>
      <form class="comment-form" novalidate>
        <label class="sr-only" for="comment-input-${post.id}">Write a comment</label>
        <input type="text" id="comment-input-${post.id}" maxlength="300" placeholder="Write a comment...">
        <button type="submit" class="btn btn-primary btn-small">Send</button>
      </form>
    </section>
  </article>`;
}

// Draws a list of posts inside a container element
function renderFeed(container, posts, emptyMessage) {
  const user = getCurrentUser();
  if (posts.length === 0) {
    container.innerHTML = `<div class="card empty-state"><p>${escapeHtml(emptyMessage || "No posts to show yet.")}</p></div>`;
    return;
  }
  container.innerHTML = posts.map((post) => renderPostCard(post, user)).join("");
}

/* =====================================================
   Post actions
   ===================================================== */

// Like or unlike
function handleLike(postId, button) {
  const user = getCurrentUser();
  const posts = getPosts();
  const post = posts.find((item) => item.id === postId);
  if (!post) return;

  const position = post.likedBy.indexOf(user.username);
  const nowLiked = position === -1;
  if (nowLiked) post.likedBy.push(user.username);   // like
  else post.likedBy.splice(position, 1);            // unlike
  savePosts(posts);

  // Update the button straight away (no page reload needed)
  button.classList.toggle("liked", nowLiked);
  button.setAttribute("aria-pressed", nowLiked);
  button.querySelector(".like-count").textContent = post.likedBy.length;
}

// Add a comment from the comment form
function handleCommentSubmit(form) {
  const card = form.closest(".post");
  const input = form.querySelector("input");
  const text = input.value.trim();

  if (text === "") {                       // empty comment check
    input.classList.add("invalid");
    showToast("Please write a comment first.", "error");
    return;
  }
  input.classList.remove("invalid");

  const user = getCurrentUser();
  const posts = getPosts();
  const post = posts.find((item) => item.id === card.dataset.postId);
  if (!post) return;

  post.comments.push({ id: "c" + Date.now(), author: user.username, text: text, time: Date.now() });
  if (!savePosts(posts)) return;

  // Show the new comment and update the number
  card.querySelector(".comment-list").innerHTML = renderComments(post.comments);
  card.querySelector(".comment-count").textContent = post.comments.length;
  input.value = "";
}

// Delete one of your own posts (after a confirmation)
function handleDelete(card, postId, onChange) {
  const user = getCurrentUser();
  const posts = getPosts();
  const post = posts.find((item) => item.id === postId);
  if (!post || post.author !== user.username) return;   // only your own posts

  if (!confirm("Delete this post? This cannot be undone.")) return;

  savePosts(posts.filter((item) => item.id !== postId));
  card.classList.add("removing");
  setTimeout(() => {
    onChange();                      // redraw the feed
    showToast("Post deleted.");
  }, 250);
}

// Share = copy a link to the post
function handleShare(postId) {
  const link = new URL("index.html#post-" + postId, window.location.href).href;
  copyToClipboard(link)
    .then(() => showToast("Post link copied!"))
    .catch(() => showToast("Could not copy the link.", "error"));
}

// Three-dot menu helpers
function closeAllMenus() {
  document.querySelectorAll(".post .menu").forEach((menu) => menu.classList.add("hidden"));
}

// Clicking anywhere outside a menu closes it
document.addEventListener("click", (event) => {
  if (!event.target.closest(".menu-wrap")) closeAllMenus();
});

/* ---------- Connects all post buttons inside one container ---------- */
// "onChange" is a function that redraws the feed (used after deleting)
function attachPostEvents(container, onChange) {
  // One click listener handles every button inside every post
  container.addEventListener("click", (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) return;
    const card = button.closest(".post");
    if (!card) return;
    const postId = card.dataset.postId;
    const action = button.dataset.action;

    if (action === "like") {
      handleLike(postId, button);
    } else if (action === "comment-toggle") {
      const section = card.querySelector(".comments");
      const isNowOpen = section.classList.toggle("hidden") === false;
      button.setAttribute("aria-expanded", isNowOpen);
      if (isNowOpen) section.querySelector("input").focus();
    } else if (action === "share") {
      handleShare(postId);
    } else if (action === "menu") {
      const menu = card.querySelector(".menu");
      const wasHidden = menu.classList.contains("hidden");
      closeAllMenus();
      menu.classList.toggle("hidden", !wasHidden);
    } else if (action === "copy") {
      const text = card.querySelector(".post-text");
      copyToClipboard(text ? text.textContent : "")
        .then(() => showToast("Text copied!"))
        .catch(() => showToast("Could not copy.", "error"));
      closeAllMenus();
    } else if (action === "delete") {
      closeAllMenus();
      handleDelete(card, postId, onChange);
    }
  });

  // Comment forms are "submitted"
  container.addEventListener("submit", (event) => {
    if (!event.target.classList.contains("comment-form")) return;
    event.preventDefault();
    handleCommentSubmit(event.target);
  });
}

/* =====================================================
   Creating a new post (Home page)
   ===================================================== */

// Makes a big photo smaller so it fits in localStorage.
// callback receives the small image (as text) or null if it failed.
function resizeImage(file, maxSize, callback) {
  const reader = new FileReader();
  reader.onload = () => {
    const image = new Image();
    image.onload = () => {
      const scale = Math.min(1, maxSize / Math.max(image.width, image.height));
      const canvas = document.createElement("canvas");
      canvas.width = Math.round(image.width * scale);
      canvas.height = Math.round(image.height * scale);
      const context = canvas.getContext("2d");
      context.fillStyle = "#111827";
      context.fillRect(0, 0, canvas.width, canvas.height);
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      callback(canvas.toDataURL("image/jpeg", 0.8));
    };
    image.onerror = () => callback(null);
    image.src = reader.result;
  };
  reader.onerror = () => callback(null);
  reader.readAsDataURL(file);
}

function initCreatePost(onPublished) {
  const form = document.getElementById("createPostForm");
  const textInput = document.getElementById("postText");
  const fileInput = document.getElementById("postImageInput");
  const previewBox = document.getElementById("imagePreviewBox");
  const previewImage = document.getElementById("previewImage");
  const removeButton = document.getElementById("removeImageBtn");
  const errorBox = document.getElementById("postError");
  const charCount = document.getElementById("charCount");

  let pendingImage = "";   // the chosen image (waiting to be published)

  function clearImage() {
    pendingImage = "";
    fileInput.value = "";
    previewImage.removeAttribute("src");
    previewBox.classList.add("hidden");
  }

  // Character counter
  textInput.addEventListener("input", () => {
    charCount.textContent = textInput.value.length + "/500";
    errorBox.textContent = "";
  });

  // When a file is chosen, check it and show a preview
  fileInput.addEventListener("change", () => {
    const file = fileInput.files[0];
    if (!file) return;
    errorBox.textContent = "";

    if (!file.type.startsWith("image/")) {
      errorBox.textContent = "Please choose an image file (JPG, PNG, GIF...).";
      clearImage();
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      errorBox.textContent = "That image is too big. Please choose one under 8 MB.";
      clearImage();
      return;
    }
    resizeImage(file, 900, (smallImage) => {
      if (!smallImage) {
        errorBox.textContent = "Sorry, that image could not be loaded.";
        clearImage();
        return;
      }
      pendingImage = smallImage;
      previewImage.src = smallImage;
      previewBox.classList.remove("hidden");   // show the preview
    });
  });

  removeButton.addEventListener("click", clearImage);

  // Publish the post
  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const text = textInput.value.trim();

    // Empty post check
    if (text === "" && pendingImage === "") {
      errorBox.textContent = "Write something or add a photo before posting.";
      textInput.classList.add("invalid");
      textInput.focus();
      return;
    }
    textInput.classList.remove("invalid");

    const user = getCurrentUser();
    const posts = getPosts();
    posts.unshift({
      id: "p" + Date.now(),
      author: user.username,
      text: text,
      image: pendingImage,
      time: Date.now(),
      likedBy: [],
      comments: []
    });
    if (!savePosts(posts)) return;

    // Reset the form and redraw the feed (no page refresh)
    textInput.value = "";
    charCount.textContent = "0/500";
    errorBox.textContent = "";
    clearImage();
    onPublished();
    showToast("Your post is published!");
  });
}

/* =====================================================
   Home page start-up
   ===================================================== */
function initHomePage() {
  if (!initPage("home")) return;

  const user = getCurrentUser();
  document.getElementById("composerAvatar").src = avatarUrl(user.username);

  const feed = document.getElementById("feed");
  const refreshFeed = () => renderFeed(feed, getPostsNewestFirst(), "No posts yet. Share something above!");
  refreshFeed();
  attachPostEvents(feed, refreshFeed);
  initCreatePost(refreshFeed);

  // Right-hand column
  document.getElementById("suggestedUsers").innerHTML =
    getDiscoverableUsers().slice(0, 4).map(renderUserRow).join("");
  renderTrending(document.getElementById("trendingList"));
}

document.addEventListener("DOMContentLoaded", () => {
  if (document.body.dataset.page === "home") initHomePage();
});
