(() => {
  const panel = document.querySelector("#call-panel");
  if (!panel) return;

  const status = panel.querySelector("[data-call-status]");
  const incoming = panel.querySelector("[data-incoming-call]");
  const incomingLabel = panel.querySelector("[data-incoming-label]");
  const active = panel.querySelector("[data-active-call]");
  const remoteVideo = panel.querySelector("[data-remote-video]");
  const localVideo = panel.querySelector("[data-local-video]");
  const userId = Number(panel.dataset.userId);
  const csrfToken = document.querySelector('input[name="csrfmiddlewaretoken"]')?.value;
  const pendingCandidates = [];
  const queuedSignals = [];
  let call = null;
  let pendingCall = null;
  let peer = null;
  let mediaStream = null;
  let lastSignalId = 0;
  let polling = false;
  let sendingCandidates = false;

  function setStatus(message) {
    status.textContent = message;
  }

  function callSignalUrl(template, callId) {
    return template.replace("/0/", `/${callId}/`);
  }

  async function request(url, options = {}) {
    const response = await fetch(url, {
      ...options,
      credentials: "same-origin",
      headers: {
        ...(options.body ? { "Content-Type": "application/json" } : {}),
        ...(csrfToken ? { "X-CSRFToken": csrfToken } : {}),
        ...options.headers,
      },
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "The call request failed.");
    return result;
  }

  async function sendSignal(type, payload = {}) {
    const result = await request(
      callSignalUrl(panel.dataset.sendSignalUrlTemplate, call.id),
      { method: "POST", body: JSON.stringify({ type, payload }) },
    );
    lastSignalId = Math.max(lastSignalId, result.signal_id);
    return result;
  }

  async function flushQueuedSignals() {
    if (!call) return;
    while (queuedSignals.length) {
      const { type, payload } = queuedSignals.shift();
      await sendSignal(type, payload);
    }
  }

  async function sendIceCandidate(candidate) {
    if (!call) {
      queuedSignals.push({ type: "ice", payload: candidate.toJSON() });
      return;
    }
    if (sendingCandidates) {
      queuedSignals.push({ type: "ice", payload: candidate.toJSON() });
      return;
    }
    sendingCandidates = true;
    try {
      await sendSignal("ice", candidate.toJSON());
      await flushQueuedSignals();
    } catch (error) {
      setStatus(error.message);
    } finally {
      sendingCandidates = false;
    }
  }

  async function drainRemoteCandidates() {
    while (peer?.remoteDescription && pendingCandidates.length) {
      await peer.addIceCandidate(pendingCandidates.shift());
    }
  }

  async function setupPeer(callType) {
    mediaStream = await navigator.mediaDevices.getUserMedia({
      audio: true,
      video: callType === "video",
    });
    localVideo.srcObject = mediaStream;
    localVideo.classList.toggle("hidden", callType !== "video");
    remoteVideo.classList.toggle("hidden", callType !== "video");

    peer = new RTCPeerConnection({
      iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
    });
    mediaStream.getTracks().forEach((track) => peer.addTrack(track, mediaStream));
    peer.onicecandidate = (event) => {
      if (event.candidate) void sendIceCandidate(event.candidate);
    };
    peer.ontrack = (event) => {
      remoteVideo.srcObject = event.streams[0];
      remoteVideo.play().catch(() => {
        setStatus("The call is connected. Use the video controls to start playback.");
      });
    };
    peer.onconnectionstatechange = () => {
      if (peer.connectionState === "connected") setStatus("Call connected.");
      if (peer.connectionState === "failed") {
        setStatus("The call connection failed. Check your network and try again.");
      }
    };
  }

  function showActiveCall() {
    active.classList.remove("hidden");
    incoming.classList.add("hidden");
  }

  function stopCall() {
    if (peer) {
      peer.onicecandidate = null;
      peer.close();
    }
    mediaStream?.getTracks().forEach((track) => track.stop());
    remoteVideo.srcObject = null;
    localVideo.srcObject = null;
    peer = null;
    mediaStream = null;
    call = null;
    pendingCall = null;
    lastSignalId = 0;
    pendingCandidates.length = 0;
    queuedSignals.length = 0;
    active.classList.add("hidden");
    incoming.classList.add("hidden");
  }

  async function startCall(callType) {
    if (!window.RTCPeerConnection || !navigator.mediaDevices?.getUserMedia) {
      setStatus("Voice and video calls require a supported browser on HTTPS or localhost.");
      return;
    }
    if (call || pendingCall) return;
    try {
      setStatus(`Starting ${callType} call...`);
      await setupPeer(callType);
      const offer = await peer.createOffer();
      await peer.setLocalDescription(offer);
      const result = await request(panel.dataset.startUrl, {
        method: "POST",
        body: JSON.stringify({ call_type: callType, offer: peer.localDescription }),
      });
      call = { id: result.call_id, call_type: callType };
      lastSignalId = result.last_signal_id;
      showActiveCall();
      setStatus(`Calling @${panel.dataset.otherUsername || "user"}...`);
      await flushQueuedSignals();
    } catch (error) {
      stopCall();
      setStatus(error.message);
    }
  }

  async function acceptCall() {
    if (!pendingCall) return;
    const acceptedCall = pendingCall;
    try {
      setStatus("Connecting call...");
      await setupPeer(acceptedCall.call_type);
      await peer.setRemoteDescription(acceptedCall.offer);
      call = { id: acceptedCall.id, call_type: acceptedCall.call_type };
      lastSignalId = acceptedCall.offer_signal_id;
      await drainRemoteCandidates();
      const answer = await peer.createAnswer();
      await peer.setLocalDescription(answer);
      await sendSignal("answer", peer.localDescription);
      showActiveCall();
      setStatus("Call answered. Connecting...");
      await flushQueuedSignals();
    } catch (error) {
      stopCall();
      setStatus(error.message);
    }
  }

  async function endCall(type) {
    const currentCall = call || pendingCall;
    if (!currentCall) return;
    if (!call) call = { id: currentCall.id };
    try {
      await sendSignal(type, {});
    } catch (error) {
      setStatus(error.message);
      return;
    }
    stopCall();
    setStatus(type === "reject" ? "Call declined." : "Call ended.");
    pendingCall = null;
  }

  async function handleSignal(signal) {
    if (signal.sender_id === userId) return;
    if (signal.type === "answer" && peer && !peer.remoteDescription) {
      await peer.setRemoteDescription(signal.payload);
      await drainRemoteCandidates();
    } else if (signal.type === "ice") {
      if (peer?.remoteDescription) {
        await peer.addIceCandidate(signal.payload);
      } else {
        pendingCandidates.push(signal.payload);
      }
    } else if (signal.type === "end" || signal.type === "reject") {
      stopCall();
      setStatus(signal.type === "reject" ? "The call was declined." : "The other user ended the call.");
    }
  }

  async function pollCallSignals() {
    const result = await request(
      `${callSignalUrl(panel.dataset.signalUrlTemplate, call.id)}?after=${lastSignalId}`,
    );
    for (const signal of result.signals) {
      await handleSignal(signal);
      lastSignalId = Math.max(lastSignalId, signal.id);
    }
    if (result.status === "ended" || result.status === "rejected") {
      stopCall();
      setStatus(result.status === "rejected" ? "The call was declined." : "The call has ended.");
    }
  }

  async function poll() {
    if (polling) return;
    polling = true;
    try {
      if (call) {
        await pollCallSignals();
      } else {
        const result = await request(panel.dataset.pollUrl);
        const incomingCall = result.call;
        if (incomingCall?.status === "ringing" && incomingCall.caller_id !== userId) {
          pendingCall = incomingCall;
          incomingLabel.textContent = `Incoming ${incomingCall.call_type} call from @${incomingCall.caller_username}`;
          incoming.classList.remove("hidden");
          setStatus("You have an incoming call.");
        } else if (!incomingCall) {
          pendingCall = null;
          incoming.classList.add("hidden");
        } else if (incomingCall.status === "active") {
          setStatus("There is already an active call. Reopen this chat to join after it ends.");
        }
      }
    } catch (error) {
      setStatus(error.message);
    } finally {
      polling = false;
    }
  }

  panel.querySelectorAll("[data-start-call]").forEach((button) => {
    button.addEventListener("click", () => void startCall(button.dataset.startCall));
  });
  panel.querySelector("[data-accept-call]").addEventListener("click", () => void acceptCall());
  panel.querySelector("[data-reject-call]").addEventListener("click", () => void endCall("reject"));
  panel.querySelector("[data-end-call]").addEventListener("click", () => void endCall("end"));
  window.setInterval(() => void poll(), 1000);
  void poll();
})();
