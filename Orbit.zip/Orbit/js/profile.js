/* =====================================================
   profile.js — the profile page
   - shows a user's details, stats and posts
   - Edit profile (own profile)
   - Follow / unfollow (other people's profiles)
   Use: profile.html            -> your own profile
        profile.html?user=name  -> someone else's profile
   ===================================================== */

let profileUsername = "";   // whose profile is being shown

/* ---------- Collect the numbers and text to display ---------- */
function getProfileData(username) {
  const me = getCurrentUser();

  // Your own profile
  if (username === me.username) {
    return { username: me.username, bio: me.bio, followers: me.followers || 0, following: getFollowingList().length, isOwn: true };
  }
  // A sample user
  const sample = SAMPLE_USERS.find((user) => user.username === username);
  if (sample) {
    return { username: sample.username, bio: sample.bio, followers: sample.followers + (isFollowing(username) ? 1 : 0), following: sample.following, isOwn: false };
  }
  // Another account created on this browser
  const account = getAccounts().find((item) => item.username === username);
  if (account) {
    return { username: account.username, bio: account.bio, followers: (account.followers || 0) + (isFollowing(username) ? 1 : 0), following: 0, isOwn: false };
  }
  return null;   // unknown user
}

// Posts written by the profile's owner
function getPostsBy(username) {
  return getPostsNewestFirst().filter((post) => post.author === username);
}

/* ---------- Update only the three numbers ---------- */
function renderProfileStats() {
  const data = getProfileData(profileUsername);
  if (!data) return;
  document.getElementById("postCount").textContent = getPostsBy(profileUsername).length;
  document.getElementById("followerCount").textContent = data.followers;
  document.getElementById("followingCount").textContent = data.following;
}

/* ---------- Draw the whole profile ---------- */
function renderProfile() {
  const data = getProfileData(profileUsername);
  const content = document.getElementById("profileContent");
  const notFound = document.getElementById("profileNotFound");

  if (!data) {                       // unknown username
    content.classList.add("hidden");
    notFound.classList.remove("hidden");
    return;
  }
  content.classList.remove("hidden");
  notFound.classList.add("hidden");

  // Pick one of three cover designs from the username
  let total = 0;
  for (const letter of data.username) total += letter.charCodeAt(0);
  document.getElementById("profileCover").className = "profile-cover cover-" + ((total % 3) + 1);

  const avatar = document.getElementById("profileAvatar");
  avatar.src = avatarUrl(data.username);
  avatar.alt = "Profile picture of " + data.username;
  document.getElementById("profileName").textContent = "@" + data.username;
  document.getElementById("profileBio").textContent = data.bio || "No biography yet.";
  document.title = "@" + data.username + " | Orbit";

  // Edit button for yourself, Follow button for others
  const actions = document.getElementById("profileActions");
  actions.innerHTML = data.isOwn
    ? '<button type="button" class="btn btn-outline" id="editProfileBtn">Edit profile</button>'
    : followButtonHtml(data.username, "");

  const editButton = document.getElementById("editProfileBtn");
  if (editButton) editButton.addEventListener("click", openEditDialog);

  renderProfilePosts();
  renderProfileStats();
}

function renderProfilePosts() {
  const container = document.getElementById("profilePosts");
  const isOwn = profileUsername === getCurrentUser().username;
  renderFeed(container, getPostsBy(profileUsername),
    isOwn ? "You have not posted yet. Share something on the Home page!" : "@" + profileUsername + " has not posted yet.");
}

/* =====================================================
   Edit profile
   ===================================================== */
function openEditDialog() {
  const me = getCurrentUser();
  document.getElementById("editUsername").value = me.username;
  document.getElementById("editBio").value = me.bio || "";
  document.getElementById("editUsernameError").textContent = "";
  document.getElementById("editBioError").textContent = "";
  document.getElementById("editDialog").showModal();
  document.getElementById("editUsername").focus();
}

// When a username changes, update every place that stores the old name
function renameUser(oldName, newName) {
  // 1. Account
  const accounts = getAccounts();
  accounts.forEach((account) => { if (account.username === oldName) account.username = newName; });
  saveData(KEYS.accounts, accounts);

  // 2. Logged-in session
  saveData(KEYS.session, { username: newName });

  // 3. Posts, comments and likes
  const posts = getPosts();
  posts.forEach((post) => {
    if (post.author === oldName) post.author = newName;
    post.likedBy = post.likedBy.map((name) => (name === oldName ? newName : name));
    post.comments.forEach((comment) => { if (comment.author === oldName) comment.author = newName; });
  });
  savePosts(posts);

  // 4. Follow lists
  const lists = loadData(KEYS.following, {});
  if (lists[oldName]) {
    lists[newName] = lists[oldName];
    delete lists[oldName];
  }
  Object.keys(lists).forEach((key) => {
    lists[key] = lists[key].map((name) => (name === oldName ? newName : name));
  });
  saveData(KEYS.following, lists);

  // 5. Notifications
  const notifications = loadData(KEYS.notifications, []);
  notifications.forEach((item) => {
    if (item.to === oldName) item.to = newName;
    if (item.from === oldName) item.from = newName;
  });
  saveData(KEYS.notifications, notifications);
}

function initEditForm() {
  const dialog = document.getElementById("editDialog");
  const form = document.getElementById("editForm");
  const usernameInput = document.getElementById("editUsername");
  const bioInput = document.getElementById("editBio");

  document.getElementById("cancelEditBtn").addEventListener("click", () => dialog.close());

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const me = getCurrentUser();
    const newName = usernameInput.value.trim();
    const newBio = bioInput.value.trim();

    // Validate the username
    const taken =
      getAccounts().some((a) => a.username.toLowerCase() === newName.toLowerCase() && a.username !== me.username) ||
      SAMPLE_USERS.some((u) => u.username.toLowerCase() === newName.toLowerCase());
    let usernameError = "";
    if (newName === "") usernameError = "Username cannot be empty.";
    else if (!/^[A-Za-z0-9_.]{3,20}$/.test(newName)) usernameError = "Use 3-20 letters, numbers, dots or underscores.";
    else if (taken) usernameError = "That username is already taken.";

    setFieldError(usernameInput, usernameError);
    if (usernameError) return;

    // Save the new bio (on the account), then the new name if it changed
    const accounts = getAccounts();
    accounts.forEach((account) => { if (account.username === me.username) account.bio = newBio; });
    saveData(KEYS.accounts, accounts);
    if (newName !== me.username) renameUser(me.username, newName);

    dialog.close();
    profileUsername = newName;
    history.replaceState(null, "", "profile.html");   // tidy the address bar
    renderNavbar("profile");
    renderProfile();
    showToast("Profile updated!");
  });
}

/* =====================================================
   Page start-up
   ===================================================== */
document.addEventListener("DOMContentLoaded", () => {
  if (document.body.dataset.page !== "profile") return;

  // Which profile? Look at ?user=... in the address
  const params = new URLSearchParams(window.location.search);
  const requested = params.get("user");
  seedDemoData();
  if (!requireLogin()) return;   // not logged in -> sent to the login page
  const me = getCurrentUser();
  profileUsername = requested || me.username;

  // The "Profile" link is highlighted only when you view your own profile
  renderNavbar(profileUsername === me.username ? "profile" : "");

  // Posts: likes, comments, delete...
  const postsContainer = document.getElementById("profilePosts");
  attachPostEvents(postsContainer, () => { renderProfilePosts(); renderProfileStats(); });

  initEditForm();
  renderProfile();

  // When you follow/unfollow, update the follower numbers
  document.addEventListener("followchange", renderProfileStats);
});
