/* =====================================================
   notifications.js — the Notifications page
   - shows likes, comments and follows
   - unread items have a blue edge and a yellow dot
   - click an item (or the button) to mark as read
   ===================================================== */

document.addEventListener("DOMContentLoaded", () => {
  if (document.body.dataset.page !== "notifications") return;
  if (!initPage("notifications")) return;

  const list = document.getElementById("notifList");
  const markAllButton = document.getElementById("markAllReadBtn");

  // Builds the sentence for each type of notification
  function buildMessage(item) {
    const name = "<strong>@" + escapeHtml(item.from) + "</strong>";
    if (item.type === "like") return name + " liked your post.";
    if (item.type === "comment") return name + " commented on your post: &ldquo;" + escapeHtml(item.message) + "&rdquo;";
    if (item.type === "follow") return name + " started following you.";
    return "<strong>" + escapeHtml(item.from) + "</strong> " + escapeHtml(item.message);   // system message
  }

  function iconFor(type) {
    if (type === "like") return "heart";
    if (type === "comment") return "comment";
    if (type === "follow") return "user";
    return "bell";
  }

  function renderNotifications() {
    const items = getMyNotifications();
    markAllButton.disabled = getUnreadCount() === 0;

    if (items.length === 0) {
      list.innerHTML = '<li class="card empty-state">You have no notifications yet.</li>';
      return;
    }
    list.innerHTML = items.map((item) => `
      <li>
        <button type="button" class="notif-item ${item.read ? "" : "unread"}" data-id="${item.id}">
          <span class="notif-icon">${icon(iconFor(item.type))}</span>
          <span class="notif-text">
            ${buildMessage(item)}<br>
            <span class="muted small">${timeAgo(item.time)}</span>
          </span>
          ${item.read ? "" : '<span class="notif-dot" title="Unread" aria-label="Unread"></span>'}
        </button>
      </li>`).join("");
    updateNotificationBadge();
  }

  // Mark one notification as read
  list.addEventListener("click", (event) => {
    const button = event.target.closest(".notif-item");
    if (!button) return;
    const all = loadData(KEYS.notifications, []);
    const item = all.find((entry) => entry.id === button.dataset.id);
    if (item && !item.read) {
      item.read = true;
      saveData(KEYS.notifications, all);
      renderNotifications();
    }
  });

  // Mark all of my notifications as read
  markAllButton.addEventListener("click", () => {
    const me = getCurrentUser();
    const all = loadData(KEYS.notifications, []);
    all.forEach((entry) => { if (entry.to === me.username) entry.read = true; });
    saveData(KEYS.notifications, all);
    renderNotifications();
    showToast("All notifications marked as read.");
  });

  renderNotifications();
});
