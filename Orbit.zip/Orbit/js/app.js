/* =====================================================
   app.js — shared code used by EVERY page
   - localStorage helpers
   - sample (demo) data
   - current user, follow system, notifications helpers
   - navigation bar, toasts, small utilities
   NOTE: Everything here is a DEMONSTRATION. There is no
   backend or database, so nothing is truly secure.
   ===================================================== */

/* ---------- Names of the localStorage entries ---------- */
const KEYS = {
  accounts: "orbit_accounts",           // demo accounts (username, email, password, bio)
  session: "orbit_session",             // who is logged in right now
  posts: "orbit_posts",                 // all posts (with likes and comments inside)
  following: "orbit_following",         // who follows whom: { username: [list] }
  notifications: "orbit_notifications", // notification list
  seeded: "orbit_seeded_v1"             // flag so sample data is only added once
};

/* ---------- Sample users (other people on the platform) ---------- */
const SAMPLE_USERS = [
  { username: "ava_designs", bio: "UI designer. Coffee, colours and clean layouts. ☕", followers: 1240, following: 310 },
  { username: "liam_codes", bio: "Learning to code one bug at a time. 💻", followers: 860, following: 420 },
  { username: "sofia.travels", bio: "Chasing sunsets around the world. 🌅", followers: 3120, following: 188 },
  { username: "noah_music", bio: "Producer. New beats every week. 🎧", followers: 2045, following: 260 },
  { username: "mia_fitness", bio: "Run, lift, repeat. Let's stay motivated! 💪", followers: 1570, following: 305 },
  { username: "zane_gamer", bio: "Streaming retro games and chill vibes. 🎮", followers: 940, following: 512 }
];

/* ---------- Trending topics ---------- */
const TRENDING_TOPICS = [
  { tag: "#WebDesign", posts: "2.4K posts" },
  { tag: "#LearnToCode", posts: "1.9K posts" },
  { tag: "#Travel", posts: "1.2K posts" },
  { tag: "#Photography", posts: "980 posts" },
  { tag: "#MondayMotivation", posts: "760 posts" }
];

/* ---------- Small SVG icons (so we need no image files) ---------- */
const ICONS = {
  home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/>',
  compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
  bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10.3 20a2 2 0 0 0 3.4 0"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
  logout: '<path d="M9 21H5V3h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
  heart: '<path d="M20.8 5.6a5.5 5.5 0 0 0-7.8 0L12 6.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 22l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>',
  comment: '<path d="M21 11.5a8.5 8.5 0 0 1-12.6 7.4L3 20l1.2-5A8.5 8.5 0 1 1 21 11.5z"/>',
  share: '<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/>',
  dots: '<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  image: '<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-9 9"/>',
  close: '<path d="M6 6l12 12M18 6L6 18"/>'
};

// Returns an <svg> string for an icon name
function icon(name, size = 20) {
  return `<svg class="icon" width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[name]}</svg>`;
}

const LOGO_SVG = '<svg viewBox="0 0 32 32" aria-hidden="true"><circle cx="16" cy="16" r="11" fill="none" stroke="#2563EB" stroke-width="3"/><circle cx="16" cy="16" r="4" fill="#2563EB"/><circle cx="26" cy="9" r="3" fill="#FACC15"/></svg>';

/* =====================================================
   localStorage helpers
   ===================================================== */

// Read saved data (returns "fallback" if nothing is saved or data is broken)
function loadData(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (error) {
    return fallback;
  }
}

// Save data. Returns true on success, false if the browser storage is full.
function saveData(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    showToast("Could not save: browser storage is full. Try a smaller image.", "error");
    return false;
  }
}

/* =====================================================
   Small utilities
   ===================================================== */

// Stops user text from being treated as HTML (important for safety)
function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

// Turns a timestamp into "5m ago", "2h ago", etc.
function timeAgo(timestamp) {
  const seconds = Math.floor((Date.now() - timestamp) / 1000);
  if (seconds < 60) return "just now";
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return minutes + "m ago";
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return hours + "h ago";
  const days = Math.floor(hours / 24);
  if (days < 7) return days + "d ago";
  return new Date(timestamp).toLocaleDateString();
}

// Creates a round profile picture (coloured circle + first letter) as an image link
function avatarUrl(username) {
  const colours = ["#2563EB", "#1D4ED8", "#3B82F6", "#4F46E5", "#0EA5E9", "#6D28D9"];
  let total = 0;
  for (const letter of username) total += letter.charCodeAt(0);
  const colour = colours[total % colours.length];
  const firstLetter = /[A-Za-z0-9]/.test(username[0]) ? username[0].toUpperCase() : "?";
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="${colour}"/><text x="50" y="50" text-anchor="middle" dominant-baseline="central" font-family="Arial, sans-serif" font-size="48" font-weight="700" fill="#F9FAFB">${firstLetter}</text></svg>`;
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
}

// Creates a decorative sample post image (so no image files are needed)
function makeSampleImage(colorA, colorB, accent) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 500"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${colorA}"/><stop offset="1" stop-color="${colorB}"/></linearGradient></defs><rect width="800" height="500" fill="url(#g)"/><circle cx="620" cy="140" r="90" fill="${accent}" opacity="0.85"/><circle cx="180" cy="380" r="140" fill="#F9FAFB" opacity="0.08"/><path d="M0 420 Q200 340 400 410 T800 380 V500 H0Z" fill="#0B0F19" opacity="0.45"/></svg>`;
  return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
}

// Shows a small pop-up message. type can be "info" or "error"
function showToast(message, type = "info") {
  let container = document.getElementById("toastContainer");
  if (!container) {
    container = document.createElement("div");
    container.id = "toastContainer";
    container.className = "toast-container";
    container.setAttribute("aria-live", "polite");
    document.body.appendChild(container);
  }
  const toast = document.createElement("div");
  toast.className = "toast" + (type === "error" ? " error" : "");
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => toast.remove(), 3200);
}

// Copies text to the clipboard (with a fallback for older browsers / local files)
function copyToClipboard(text) {
  if (navigator.clipboard && window.isSecureContext) {
    return navigator.clipboard.writeText(text);
  }
  return new Promise((resolve, reject) => {
    const box = document.createElement("textarea");
    box.value = text;
    box.style.position = "fixed";
    box.style.opacity = "0";
    document.body.appendChild(box);
    box.select();
    const worked = document.execCommand("copy");
    box.remove();
    worked ? resolve() : reject();
  });
}

/* =====================================================
   Sample data (added only the first time the site opens)
   ===================================================== */
function seedDemoData() {
  if (localStorage.getItem(KEYS.seeded)) return;

  const now = Date.now();
  const MIN = 60000, HOUR = 3600000, DAY = 86400000;
  const fakeLikes = (count) => Array.from({ length: count }, (_, i) => "fan_" + (i + 1));

  // One demo account you can log in with
  saveData(KEYS.accounts, [
    { username: "demo", email: "demo@example.com", password: "demo1234", bio: "Just exploring Orbit! 🚀 This is a demo profile.", followers: 24 }
  ]);

  // Who the demo user already follows
  saveData(KEYS.following, { demo: ["ava_designs", "liam_codes"] });

  // Sample posts
  saveData(KEYS.posts, [
    { id: "p1", author: "ava_designs", text: "Just wrapped up a new dashboard concept. Dark mode with blue accents is hard to beat! 💙 #WebDesign",
      image: makeSampleImage("#1D4ED8", "#0B0F19", "#FACC15"), time: now - 25 * MIN, likedBy: fakeLikes(48),
      comments: [{ id: "c1", author: "liam_codes", text: "This looks amazing! Love the contrast.", time: now - 18 * MIN }] },
    { id: "p2", author: "liam_codes", text: "Day 30 of #LearnToCode: I finally understand how event listeners work. Small wins add up!",
      image: "", time: now - 2 * HOUR, likedBy: fakeLikes(31),
      comments: [{ id: "c2", author: "ava_designs", text: "Keep going, you are doing great!", time: now - 1 * HOUR },
                 { id: "c3", author: "zane_gamer", text: "Event listeners clicked for me on day 20. Nice!", time: now - 50 * MIN }] },
    { id: "p3", author: "sofia.travels", text: "Golden hour at the coast. Nothing beats it. 🌅 #Travel #Photography",
      image: makeSampleImage("#2563EB", "#111827", "#FACC15"), time: now - 5 * HOUR, likedBy: fakeLikes(112), comments: [] },
    { id: "p4", author: "noah_music", text: "New beat dropping this weekend 🎧 Who wants a sneak peek?",
      image: "", time: now - 9 * HOUR, likedBy: fakeLikes(54),
      comments: [{ id: "c4", author: "mia_fitness", text: "Yes please! Perfect for my workout playlist.", time: now - 8 * HOUR }] },
    { id: "p5", author: "mia_fitness", text: "Morning run done ✅ Rise and shine, it's going to be a great week! #MondayMotivation",
      image: makeSampleImage("#0B0F19", "#2563EB", "#F9FAFB"), time: now - 1 * DAY, likedBy: fakeLikes(76), comments: [] },
    { id: "p6", author: "zane_gamer", text: "Hot take: pixel art will never go out of style. 🎮 #Photography #WebDesign",
      image: "", time: now - 2 * DAY, likedBy: fakeLikes(22), comments: [] },
    { id: "p7", author: "demo", text: "Hello Orbit! This is my first post on this demo platform. 👋",
      image: "", time: now - 3 * DAY, likedBy: ["ava_designs", "liam_codes", "fan_1"],
      comments: [{ id: "c5", author: "ava_designs", text: "Welcome to Orbit!", time: now - 3 * DAY + 20 * MIN }] },
    { id: "p8", author: "demo", text: "Learning HTML, CSS and JavaScript step by step. #LearnToCode",
      image: "", time: now - 4 * DAY, likedBy: ["noah_music"], comments: [] }
  ]);

  // Sample notifications for the demo user
  saveData(KEYS.notifications, [
    { id: "n1", to: "demo", type: "like", from: "ava_designs", message: "", time: now - 10 * MIN, read: false },
    { id: "n2", to: "demo", type: "comment", from: "liam_codes", message: "Great first post, welcome!", time: now - 40 * MIN, read: false },
    { id: "n3", to: "demo", type: "follow", from: "sofia.travels", message: "", time: now - 3 * HOUR, read: false },
    { id: "n4", to: "demo", type: "like", from: "noah_music", message: "", time: now - 1 * DAY, read: true },
    { id: "n5", to: "demo", type: "follow", from: "mia_fitness", message: "", time: now - 2 * DAY, read: true }
  ]);

  localStorage.setItem(KEYS.seeded, "yes");
}

/* =====================================================
   Current user
   ===================================================== */
function getAccounts() {
  return loadData(KEYS.accounts, []);
}

// Returns the logged-in account object, or null if nobody is logged in
function getCurrentUser() {
  const session = loadData(KEYS.session, null);
  if (!session) return null;
  return getAccounts().find((account) => account.username === session.username) || null;
}

// If nobody is logged in, send the visitor to the login page
function requireLogin() {
  if (!getCurrentUser()) {
    window.location.replace("login.html");
    return false;
  }
  return true;
}

// Standard start-up for every page that needs a logged-in user
function initPage(activePage) {
  seedDemoData();
  if (!requireLogin()) return false;
  renderNavbar(activePage);
  return true;
}

/* =====================================================
   Follow system (shared by home, explore and profile pages)
   ===================================================== */
function getFollowingList() {
  const user = getCurrentUser();
  const allLists = loadData(KEYS.following, {});
  return (user && allLists[user.username]) || [];
}

function isFollowing(username) {
  return getFollowingList().includes(username);
}

// Follows or unfollows. Returns true if the user is now following.
function toggleFollow(username) {
  const user = getCurrentUser();
  const allLists = loadData(KEYS.following, {});
  let list = allLists[user.username] || [];
  if (list.includes(username)) {
    list = list.filter((name) => name !== username);
  } else {
    list.push(username);
  }
  allLists[user.username] = list;
  saveData(KEYS.following, allLists);
  return list.includes(username);
}

// Changes how a follow button looks
function updateFollowButton(button, following) {
  button.textContent = following ? "Following" : "Follow";
  button.classList.toggle("btn-outline", following);
  button.classList.toggle("btn-primary", !following);
  button.classList.toggle("following", following);
  button.setAttribute("aria-pressed", following);
  button.title = following ? "Click to unfollow" : "Click to follow";
}

// HTML for a follow button
function followButtonHtml(username, extraClass = "btn-small") {
  const following = isFollowing(username);
  return `<button type="button" class="btn ${extraClass} follow-btn ${following ? "btn-outline following" : "btn-primary"}" data-username="${escapeHtml(username)}" aria-pressed="${following}" title="${following ? "Click to unfollow" : "Click to follow"}">${following ? "Following" : "Follow"}</button>`;
}

// One click listener handles every follow button on every page
document.addEventListener("click", (event) => {
  const button = event.target.closest(".follow-btn");
  if (!button) return;
  const username = button.dataset.username;
  const nowFollowing = toggleFollow(username);
  // Update every button for this person (they can appear in several places)
  document.querySelectorAll(".follow-btn").forEach((other) => {
    if (other.dataset.username === username) updateFollowButton(other, nowFollowing);
  });
  showToast(nowFollowing ? "You are now following @" + username : "You unfollowed @" + username);
  // Tell the page (for example the profile page) so it can update counts
  document.dispatchEvent(new CustomEvent("followchange", { detail: { username, following: nowFollowing } }));
});

/* =====================================================
   Suggested users & trending (used on home and explore)
   ===================================================== */

// Sample users + any other accounts created on this browser (except me)
function getDiscoverableUsers() {
  const me = getCurrentUser();
  const others = getAccounts()
    .filter((account) => account.username !== me.username)
    .map((account) => ({ username: account.username, bio: account.bio, followers: account.followers || 0, following: 0 }));
  return SAMPLE_USERS.concat(others);
}

function renderUserRow(user) {
  const name = escapeHtml(user.username);
  const link = "profile.html?user=" + encodeURIComponent(user.username);
  return `<li class="user-row">
    <a href="${link}"><img class="avatar" src="${avatarUrl(user.username)}" alt="Profile picture of ${name}"></a>
    <div class="user-info">
      <a class="user-name" href="${link}">@${name}</a>
      <span class="muted small">${escapeHtml(user.bio || "")}</span>
    </div>
    ${followButtonHtml(user.username)}
  </li>`;
}

function renderTrending(container) {
  container.innerHTML = TRENDING_TOPICS.map((topic) =>
    `<li><a href="explore.html?topic=${encodeURIComponent(topic.tag)}"><strong>${topic.tag}</strong><span class="muted small">${topic.posts}</span></a></li>`
  ).join("");
}

/* =====================================================
   Notification helpers
   ===================================================== */
function getMyNotifications() {
  const user = getCurrentUser();
  return loadData(KEYS.notifications, [])
    .filter((item) => item.to === user.username)
    .sort((a, b) => b.time - a.time);
}

function getUnreadCount() {
  return getMyNotifications().filter((item) => !item.read).length;
}

// Updates the yellow number badge in the navigation bar
function updateNotificationBadge() {
  const badge = document.getElementById("notifBadge");
  if (!badge) return;
  const count = getUnreadCount();
  badge.textContent = count;
  badge.classList.toggle("hidden", count === 0);
}

// Adds a new notification for a user
function addNotification(to, type, from, message) {
  const all = loadData(KEYS.notifications, []);
  all.push({ id: "n" + Date.now() + Math.floor(Math.random() * 1000), to, type, from, message, time: Date.now(), read: false });
  saveData(KEYS.notifications, all);
}

/* =====================================================
   Navigation bar (built with JavaScript so every page shares it)
   ===================================================== */
function renderNavbar(activePage) {
  const nav = document.getElementById("navbar");
  const user = getCurrentUser();
  if (!nav || !user) return;

  // Helper that builds one navigation link
  const link = (href, page, iconName, label) =>
    `<a href="${href}" class="nav-link ${activePage === page ? "active" : ""}" ${activePage === page ? 'aria-current="page"' : ""}>${icon(iconName)}<span>${label}</span></a>`;

  nav.innerHTML = `
    <div class="nav-inner">
      <a href="index.html" class="logo" aria-label="Orbit home">${LOGO_SVG}<span>Orbit</span></a>
      <button type="button" class="menu-toggle" id="menuToggle" aria-label="Open menu" aria-expanded="false" aria-controls="navLinks">${icon("menu", 24)}</button>
      <nav class="nav-links" id="navLinks" aria-label="Main navigation">
        ${link("index.html", "home", "home", "Home")}
        ${link("explore.html", "explore", "compass", "Explore")}
        <a href="explore.html#search" class="nav-link" id="searchLink">${icon("search")}<span>Search</span></a>
        <a href="notifications.html" class="nav-link ${activePage === "notifications" ? "active" : ""}" aria-label="Notifications">${icon("bell")}<span>Notifications</span><span class="badge" id="notifBadge">0</span></a>
        <a href="profile.html" class="nav-link ${activePage === "profile" ? "active" : ""}"><img class="avatar avatar-xs" src="${avatarUrl(user.username)}" alt=""><span>Profile</span></a>
        <button type="button" class="nav-link nav-logout" id="logoutBtn">${icon("logout")}<span>Logout</span></button>
      </nav>
    </div>`;

  updateNotificationBadge();

  // Mobile menu: open / close
  const toggle = document.getElementById("menuToggle");
  const links = document.getElementById("navLinks");
  toggle.addEventListener("click", () => {
    const isOpen = links.classList.toggle("open");
    toggle.setAttribute("aria-expanded", isOpen);
    toggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
  });
  // Close the menu after choosing a link
  links.addEventListener("click", (event) => {
    if (event.target.closest("a")) links.classList.remove("open");
  });
  // Close the menu with the Escape key
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") links.classList.remove("open");
  });
}
