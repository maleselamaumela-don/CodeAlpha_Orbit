# Orbit

Orbit is a Django-backed social app with a SQLite database for user accounts,
posts, comments, likes, and follower relationships. Users can like and unlike
posts and comments, see their like counts, comment on other users' posts,
update their biography, and upload or replace a profile picture from their
profile page at any time.

## Run locally

1. Create and activate a virtual environment.
2. Install the dependencies:

   ```powershell
   python -m pip install -r requirements.txt
   ```

3. Create the database tables:

   ```powershell
   python manage.py migrate
   ```

4. Start the development server:

   ```powershell
   python manage.py runserver
   ```

5. Open <http://127.0.0.1:8000/> and create an account.

To populate the Home feed with 30 sample posts and matching photos, run this
once after migrations:

```powershell
python manage.py seed_demo_posts
```

The command is safe to rerun. It creates sample accounts with unusable
passwords and does not replace your own posts. Demo users get profile pictures
cropped from project photos, and each of the 30 sample posts uses a photo from
`images/`. Existing custom images and posts from your own account are preserved.
Sample profiles use fictional African and American names. Existing demo accounts
are renamed in place so their posts and profile pictures remain linked.

The demo accounts also simulate followers for each other and for registered
users. Posts from real users receive 3 clearly labeled simulated likes every
10 minutes, up to 30 likes per post. The post timer starts when the post is
created. Run this command to process likes that are due:

```powershell
python manage.py process_demo_engagement
```

For automatic processing on Windows, configure Task Scheduler to run
`python manage.py process_demo_engagement` every 10 minutes, with the project
folder as the task's **Start in** directory. If no scheduled task is set up,
likes are added only when this command is run; the Django web server does not
run a background timer on its own.

To view posts from another account locally, register a second user in another
browser session (or log out and back in as that user) and publish posts. The
Home feed shows posts from all accounts in the database; Explore lists other
registered users and their posts. Home feed posts are shuffled each time the
feed loads. Use the photo upload on a post to share a real image, and edit your
profile to upload or replace your profile picture.
Posts use captions without categories. When sharing a photo, add a caption that
accurately describes what is shown. The app does not automatically analyze
user-uploaded photos to verify caption accuracy.
Use **Repost** on another user's post to add it to your feed and profile; likes
and comments on reposts remain attached to the original. **Share** opens the
device's sharing menu when available, or copies a link to the post.
Use **Messages** in the navigation bar, or the **Message** button on a profile
or Explore user, to open a private conversation. Each sent message receives a
friendly, varied quick reply that is identified as automatic in the conversation.
Start a voice or video call from an open conversation and accept the incoming
call in the other user's copy of that conversation. Calls use browser WebRTC,
so both users must allow microphone/camera access; browsers require HTTPS
(except on localhost). Call setup uses Google's public STUN service to help
connect users through common network configurations. Signaling is exchanged
through the Django app, while live audio/video streams are peer-to-peer.

To manage users and social data, create an administrator with
`python manage.py createsuperuser` and visit <http://127.0.0.1:8000/admin/>.

SQLite data is stored in `db.sqlite3`; uploaded profile and post images are
stored in `media/`. Both are created locally and should not be committed.
`media/` serving is enabled only while Django `DEBUG` is on.

## Main routes

| Route | Purpose |
|---|---|
| `/accounts/register/` | Create a user account |
| `/accounts/login/` | Log in |
| `/accounts/logout/` | Log out (POST) |
| `/` | Create posts and view the feed |
| `/explore/` | Discover registered users and browse their posts |
| `/messages/` | View conversations and find people to message |
| `/messages/<username>/` | Open a private conversation |
| `/posts/<id>/` | Open a post permalink |
| `/profile/` | View and edit your profile |
| `/profile/<username>/` | View a user's profile and follow/unfollow |
| `/admin/` | Manage users, posts, comments, and follows |

The original standalone HTML pages and JavaScript are retained as the initial
frontend prototype. Run the Django server to use the database-backed app.

## Configuration

For deployment, set `DJANGO_SECRET_KEY` to a private random value,
`DJANGO_DEBUG=0`, and `DJANGO_ALLOWED_HOSTS` to the allowed hostnames. Configure
a production database and media storage before deploying; Django's development
server and local media serving are not production hosting.
